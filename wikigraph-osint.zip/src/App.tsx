import React, { useState, useEffect, useRef, useCallback } from 'react';
import ForceGraph2D from 'react-force-graph-2d';
import { Search, Loader2, Share2, Terminal as TerminalIcon, History, Trash2, Maximize2, Minimize2, ZoomIn, Sparkles } from 'lucide-react';
import { GoogleGenAI, Type } from "@google/genai";
import axios from 'axios';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { jsonrepair } from 'jsonrepair';
import { GraphData, Node, WikiExtract } from './types';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const GRAPH_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    nodes: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.STRING, description: "Unique identifier for the entity" },
          label: { type: Type.STRING, description: "Display name of the entity" },
          type: { 
            type: Type.STRING, 
            enum: ["person", "company", "technology", "organization", "location", "other"],
            description: "Category of the entity"
          }
        },
        required: ["id", "label", "type"]
      }
    },
    links: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          source: { type: Type.STRING, description: "ID of the starting node" },
          target: { type: Type.STRING, description: "ID of the target node" },
          label: { type: Type.STRING, description: "The relationship between source and target" }
        },
        required: ["source", "target", "label"]
      }
    }
  },
  required: ["nodes", "links"]
};

const NODE_COLORS = {
  person: '#ff4b4b',
  company: '#1c92ff',
  technology: '#00ffcc',
  organization: '#ffcc00',
  location: '#cc00ff',
  other: '#aaaaaa'
};

// Gemini Initialization
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY as string });

export default function App() {
  const [topic, setTopic] = useState('');
  const [loading, setLoading] = useState(false);
  const [streaming, setStreaming] = useState(false);
  const [logs, setLogs] = useState<{msg: string, type: 'info' | 'success' | 'error'}[]>([]);
  const [data, setData] = useState<GraphData>({ nodes: [], links: [] });
  const [history, setHistory] = useState<string[]>([]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const fgRef = useRef<any>();

  useEffect(() => {
    if (fgRef.current) {
      fgRef.current.d3Force('charge').strength(-200);
      fgRef.current.d3Force('link').distance(70);
      fgRef.current.d3Force('center').strength(0.05);
    }
  }, [data]);

  const addLog = (msg: string, type: 'info' | 'success' | 'error' = 'info') => {
    setLogs(prev => [{ msg, type }, ...prev].slice(0, 50));
  };

  const processWikiData = async (query: string) => {
    if (!query.trim()) return;
    setLoading(true);
    addLog(`Searching Wikipedia for: ${query}...`, 'info');

    try {
      const wikiRes = await axios.get(`/api/wiki?topic=${encodeURIComponent(query)}`);
      const wikiData: WikiExtract = wikiRes.data;
      
      addLog(`Wikipedia found: ${wikiData.title} (${wikiData.lang})`, 'success');
      addLog(`Extracting entities with streaming AI...`, 'info');

      setStreaming(true);
      const stream = await ai.models.generateContentStream({
        model: "gemini-3-flash-preview",
        contents: `Analyze the following technical information about "${wikiData.title}" and extract a knowledge graph of entities and their relationships. 
        Focus on key figures, companies, technologies, and organizations.
        
        Information:
        ${wikiData.extract}`,
        config: {
          responseMimeType: "application/json",
          responseSchema: GRAPH_SCHEMA as any
        }
      });

      let fullText = "";
      for await (const chunk of stream) {
        const chunkText = chunk.text;
        fullText += chunkText;

        try {
          // Attempt to repair and parse partial JSON
          const repaired = jsonrepair(fullText);
          const partialResult = JSON.parse(repaired) as GraphData;

          if (partialResult.nodes || partialResult.links) {
            updateGraphIncremental(partialResult);
          }
        } catch (e) {
          // Expected during streaming as JSON is incomplete
        }
      }

      addLog(`Extraction complete.`, 'success');
      if (!history.includes(query)) {
        setHistory(prev => [query, ...prev]);
      }

    } catch (err: any) {
      console.error(err);
      addLog(`Error: ${err.message || 'Unknown error'}`, 'error');
    } finally {
      setLoading(false);
      setStreaming(false);
      setTopic('');
    }
  };

  const updateGraphIncremental = (partialResult: GraphData) => {
    setData(prev => {
      const nodeMap = new Map(prev.nodes.map(n => [n.id, n]));
      let hasChanges = false;

      (partialResult.nodes || []).forEach(n => {
        if (!nodeMap.has(n.id)) {
          nodeMap.set(n.id, {
            ...n,
            color: NODE_COLORS[n.type as keyof typeof NODE_COLORS] || NODE_COLORS.other,
            val: 1
          });
          hasChanges = true;
        }
      });

      const getLinkId = (l: any) => {
        const s = typeof l.source === 'object' ? l.source.id : l.source;
        const t = typeof l.target === 'object' ? l.target.id : l.target;
        return `${s}-${t}-${l.label}`;
      };

      const linkMap = new Map(prev.links.map(l => [getLinkId(l), l]));
      (partialResult.links || []).forEach(l => {
        const id = `${l.source}-${l.target}-${l.label}`;
        if (!linkMap.has(id)) {
          linkMap.set(id, l);
          hasChanges = true;
        }
      });

      if (!hasChanges) return prev;
      return {
        nodes: Array.from(nodeMap.values()),
        links: Array.from(linkMap.values())
      };
    });
  };


  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    processWikiData(topic);
  };

  const clearGraph = () => {
    setData({ nodes: [], links: [] });
    setLogs([]);
    addLog('Graph cleared', 'info');
  };

  const zoomToFit = useCallback(() => {
    if (fgRef.current) {
        fgRef.current.zoomToFit(400);
    }
  }, []);

  return (
    <div className="flex h-screen w-full bg-[#0a0a0a] text-gray-200 font-sans overflow-hidden">
      {/* Sidebar */}
      <motion.div 
        initial={false}
        animate={{ width: isSidebarOpen ? 320 : 0, opacity: isSidebarOpen ? 1 : 0 }}
        className="flex flex-col bg-[#111111] border-r border-gray-800 z-20 relative"
      >
        <div className="p-4 flex flex-col h-full gap-4 min-w-[320px]">
          <div className="flex items-center gap-2 mb-2">
            <Share2 className="w-6 h-6 text-blue-500" />
            <h1 className="text-xl font-bold tracking-tight text-white">WikiGraph OSINT</h1>
          </div>

          <form onSubmit={handleSearch} className="space-y-2">
            <div className="relative">
              <input
                type="text"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="Enter topic (e.g. OpenAI)..."
                className="w-full bg-[#1a1a1a] border border-gray-700 rounded-md py-2 pl-4 pr-10 focus:outline-none focus:border-blue-500 text-sm transition-all"
                disabled={loading}
              />
              <button 
                type="submit" 
                className="absolute right-2 top-1.5 p-1 text-gray-400 hover:text-white disabled:opacity-50"
                disabled={loading}
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
              </button>
            </div>
          </form>

          {/* History */}
          <div className="flex-1 flex flex-col min-h-0">
            <div className="flex items-center justify-between text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
              <div className="flex items-center gap-1">
                <History className="w-3 h-3" /> Search History
              </div>
            </div>
            <div className="flex-1 overflow-y-auto space-y-1 pr-2 custom-scrollbar">
              {history.length === 0 && <span className="text-xs text-gray-600 italic">No history yet</span>}
              {history.map((h, i) => (
                <button
                  key={i}
                  onClick={() => processWikiData(h)}
                  className="w-full text-left p-2 rounded hover:bg-[#1a1a1a] text-sm text-gray-400 hover:text-gray-200 transition-colors truncate"
                  disabled={loading}
                >
                  {h}
                </button>
              ))}
            </div>
          </div>

          {/* Terminal / Logs */}
          <div className="h-1/3 flex flex-col border-t border-gray-800 pt-4 min-h-0">
            <div className="flex items-center justify-between text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
              <div className="flex items-center gap-1">
                <TerminalIcon className="w-3 h-3" /> System Terminal
              </div>
              <button onClick={() => setLogs([])} className="hover:text-red-400 transition-colors">
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto bg-black rounded p-3 font-mono text-[10px] space-y-1 custom-scrollbar">
              {logs.map((log, i) => (
                <div key={i} className={cn(
                  "animate-in fade-in slide-in-from-left-1 duration-300",
                  log.type === 'error' ? 'text-red-500' : log.type === 'success' ? 'text-green-500' : 'text-gray-400'
                )}>
                  <span className="opacity-50 mr-1">[{new Date().toLocaleTimeString([], { hour12: false })}]</span>
                  {log.msg}
                </div>
              ))}
              {logs.length === 0 && <span className="text-gray-700 italic">Awaiting input...</span>}
            </div>
          </div>
        </div>
      </motion.div>

      {/* Main Graph Area */}
      <div className="flex-1 relative">
        <AnimatePresence>
          {streaming && (
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="absolute top-4 right-4 z-10 flex items-center gap-2 px-3 py-1 bg-blue-500/10 border border-blue-500/20 rounded-full text-[10px] text-blue-400"
            >
              <Sparkles className="w-3" />
              AI STREAMING ACTIVE...
            </motion.div>
          )}
        </AnimatePresence>
        <div className="absolute top-4 left-4 z-10 flex gap-2">
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-2 bg-[#111111]/80 backdrop-blur border border-gray-800 rounded-md hover:bg-gray-800 transition-all text-gray-400 hover:text-white"
          >
            {isSidebarOpen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
          <button 
            onClick={zoomToFit}
            className="p-2 bg-[#111111]/80 backdrop-blur border border-gray-800 rounded-md hover:bg-gray-800 transition-all text-gray-400 hover:text-white"
            title="Auto Fit"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button 
            onClick={clearGraph}
            className="p-2 bg-[#111111]/80 backdrop-blur border border-gray-800 rounded-md hover:bg-gray-800 transition-all text-gray-400 hover:text-white"
            title="Clear Graph"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>

        {/* Legend */}
        <div className="absolute bottom-4 left-4 z-10 bg-[#111111]/80 backdrop-blur border border-gray-800 rounded-lg p-3 text-[10px] grid grid-cols-2 gap-x-4 gap-y-1">
          {Object.entries(NODE_COLORS).map(([type, color]) => (
            <div key={type} className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: color }} />
              <span className="capitalize text-gray-400">{type}</span>
            </div>
          ))}
        </div>

        {/* Empty State */}
        {data.nodes.length === 0 && !loading && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-0">
            <div className="text-center space-y-4 max-w-md p-8">
              <div className="w-16 h-16 bg-blue-500/10 border border-blue-500/20 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Share2 className="w-8 h-8 text-blue-500 animate-pulse" />
              </div>
              <h2 className="text-2xl font-bold text-white">WikiGraph Explorer</h2>
              <p className="text-gray-500 text-sm leading-relaxed">
                Enter a topic in the sidebar to start extracting a knowledge graph. 
                We use Wikipedia for data and Gemini 1.5 Flash for entity-relation extraction.
              </p>
              <div className="flex flex-wrap justify-center gap-2 pt-4">
                {['Elon Musk', 'SpaceX', 'DeepMind', 'Quantum Computing'].map(t => (
                  <button 
                    key={t}
                    onClick={() => processWikiData(t)}
                    className="pointer-events-auto px-3 py-1 bg-[#1a1a1a] border border-gray-700 rounded-full text-[10px] hover:border-blue-500 transition-colors"
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Initializing State */}
        {loading && data.nodes.length === 0 && (
          <div className="absolute inset-0 bg-[#0a0a0a]/50 backdrop-blur-sm z-10 flex items-center justify-center">
            <div className="flex flex-col items-center gap-4">
              <Loader2 className="w-12 h-12 text-blue-500 animate-spin" />
              <p className="text-sm font-mono text-blue-500 animate-pulse">EXTRACTING KNOWLEDGE GRAPH...</p>
            </div>
          </div>
        )}

        <ForceGraph2D
          ref={fgRef}
          graphData={data}
          nodeLabel="label"
          nodeColor="color"
          onNodeClick={(node: any) => {
            if (loading) return;
            addLog(`Exploring nodes connected to: ${node.label}...`, 'info');
            processWikiData(node.label);
          }}
          onNodeDragEnd={(node: any) => {
            node.fx = node.x;
            node.fy = node.y;
          }}
          d3AlphaDecay={0.02}
          d3VelocityDecay={0.3}
          cooldownTicks={100}
          linkColor={() => 'rgba(255, 255, 255, 0.1)'}
          linkDirectionalParticles={2}
          linkDirectionalParticleSpeed={0.005}
          linkDirectionalParticleWidth={1}
          linkDirectionalParticleColor={() => '#3b82f6'}
          nodeRelSize={4}
          linkCanvasObject={(link: any, ctx) => {
            const MAX_FONT_SIZE = 4;
            const LABEL_THRESHOLD = 8;
            
            if (ctx.getTransform().a < LABEL_THRESHOLD / 2) return;

            const start = link.source;
            const end = link.target;
            if (typeof start !== 'object' || typeof end !== 'object') return;

            const textPos = {
              x: start.x + (end.x - start.x) / 2,
              y: start.y + (end.y - start.y) / 2
            };

            const relAngle = Math.atan2(end.y - start.y, end.x - start.x);
            const label = link.label;

            ctx.save();
            ctx.translate(textPos.x, textPos.y);
            ctx.rotate(relAngle);
            ctx.font = `${MAX_FONT_SIZE}px sans-serif`;
            ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
            ctx.textAlign = 'center';
            ctx.fillText(label, 0, -2);
            ctx.restore();
          }}
          nodeCanvasObject={(node, ctx, globalScale) => {
            const label = node.label as string;
            const size = 3;
            ctx.beginPath();
            ctx.arc(node.x!, node.y!, size, 0, 2 * Math.PI, false);
            ctx.fillStyle = (node as any).color;
            ctx.fill();
            
            if (globalScale > 3) {
              const fontSize = 12 / globalScale;
              ctx.font = `${fontSize}px sans-serif`;
              ctx.textAlign = 'center';
              ctx.textBaseline = 'middle';
              ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
              ctx.fillText(label, node.x!, node.y! + size + 2);
            }
          }}
          nodeCanvasObjectMode={() => 'replace'}
        />
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #333;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #444;
        }
      `}} />
    </div>
  );
}

