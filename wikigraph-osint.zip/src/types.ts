export interface Node {
  id: string;
  label: string;
  type: 'person' | 'company' | 'technology' | 'organization' | 'location' | 'other';
  color?: string;
  val?: number;
}

export interface Link {
  source: string;
  target: string;
  label: string;
}

export interface GraphData {
  nodes: Node[];
  links: Link[];
}

export interface WikiExtract {
  title: string;
  extract: string;
  lang: string;
}
