import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import axios from "axios";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route for Wikipedia Proxy
  // We proxy this to avoid CORS issues and to handle language detection easily
  app.get("/api/wiki", async (req, res) => {
    const { topic, lang = 'zh' } = req.query;
    if (!topic) {
        return res.status(400).json({ error: "Topic is required" });
    }

    try {
        // Wikipedia search to get the correct title first
        const searchUrl = `https://${lang}.wikipedia.org/w/api.php?action=query&format=json&list=search&srsearch=${encodeURIComponent(topic as string)}&srlimit=1`;
        const searchResponse = await axios.get(searchUrl, { headers: { 'User-Agent': 'WikiGraphOSINT/1.0' } });
        
        let targetTitle = topic as string;
        if (searchResponse.data.query.search.length > 0) {
            targetTitle = searchResponse.data.query.search[0].title;
        }

        // Fetch extract
        const extractUrl = `https://${lang}.wikipedia.org/w/api.php?action=query&format=json&prop=extracts&exintro&explaintext&redirects=1&titles=${encodeURIComponent(targetTitle)}`;
        const response = await axios.get(extractUrl, { headers: { 'User-Agent': 'WikiGraphOSINT/1.0' } });

        const pages = response.data.query.pages;
        const pageId = Object.keys(pages)[0];
        
        if (pageId === "-1") {
            return res.status(404).json({ error: "Topic not found" });
        }

        res.json({ 
            title: pages[pageId].title, 
            extract: pages[pageId].extract,
            lang
        });
    } catch (error) {
        res.status(500).json({ error: "Failed to fetch Wikipedia data" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
