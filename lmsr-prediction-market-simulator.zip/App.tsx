
import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  Settings, 
  BarChart3
} from 'lucide-react';
import { MarketState, Outcome } from './types';
import { 
  calculateInitialBias, 
  calculateTrade 
} from './logic/lmsr';
import MarketConfig from './components/MarketConfig';
import TradingTerminal from './components/TradingTerminal';
import MarketCharts from './components/MarketCharts';

const App: React.FC = () => {
  const [market, setMarket] = useState<MarketState>({
    b: 20,
    qYes: 0,
    qNo: 0,
    initialProb: 0.5
  });

  // Initialize market when B or InitialProb changes
  useEffect(() => {
    const { qYes, qNo } = calculateInitialBias(market.initialProb, market.b);
    setMarket(prev => ({ ...prev, qYes, qNo }));
  }, [market.b, market.initialProb]);

  const handleTrade = (outcome: Outcome, amount: number) => {
    const trade = calculateTrade(outcome, amount, market.qYes, market.qNo, market.b);
    setMarket(prev => ({
      ...prev,
      qYes: outcome === 'YES' ? prev.qYes + amount : prev.qYes,
      qNo: outcome === 'NO' ? prev.qNo + amount : prev.qNo
    }));
  };

  return (
    <div className="flex flex-col min-h-screen bg-slate-950 text-slate-200">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-md sticky top-0 z-50 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-600 rounded-lg">
              <TrendingUp className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-xl font-bold tracking-tight">LMSR Market Simulator</h1>
          </div>
          <div className="flex items-center gap-4 text-sm font-medium text-slate-400">
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              Live Simulation
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto w-full p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Config */}
        <div className="lg:col-span-4 flex flex-col gap-6">
          <section className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
            <div className="flex items-center gap-2 mb-6">
              <Settings className="w-5 h-5 text-indigo-400" />
              <h2 className="text-lg font-semibold">Market Configuration</h2>
            </div>
            <MarketConfig 
              b={market.b} 
              initialProb={market.initialProb} 
              onUpdate={(updates) => setMarket(prev => ({ ...prev, ...updates }))} 
            />
          </section>
        </div>

        {/* Right Column: Visualizations & Trading */}
        <div className="lg:col-span-8 flex flex-col gap-6">
          
          <section className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-indigo-400" />
                <h2 className="text-lg font-semibold">Cost Function Visualization</h2>
              </div>
            </div>
            <div className="h-[400px] w-full">
              <MarketCharts market={market} />
            </div>
          </section>

          <TradingTerminal 
            market={market} 
            onTrade={handleTrade} 
          />
        </div>
      </main>
      
      <footer className="mt-auto border-t border-slate-800 p-6 text-center text-slate-500 text-sm">
        <p>&copy; 2024 Prediction Market LMSR Simulator. Advanced AMM Engineering.</p>
      </footer>
    </div>
  );
};

export default App;
