
export interface MarketState {
  b: number;         // Liquidity parameter
  qYes: number;      // Shares of YES bought
  qNo: number;       // Shares of NO bought
  initialProb: number; // Target initial probability
}

export interface TradeResult {
  cost: number;
  newQYes: number;
  newQNo: number;
  slippage: number;
}

export type Outcome = 'YES' | 'NO';
