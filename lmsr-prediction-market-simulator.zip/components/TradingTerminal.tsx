
import React, { useState, useEffect, useMemo } from 'react';
import { MarketState, Outcome } from '../types';
import { calculateTrade, getPrice } from '../logic/lmsr';
import { ArrowUpRight, RefreshCw, TrendingUp } from 'lucide-react';

interface TradingTerminalProps {
  market: MarketState;
  onTrade: (outcome: Outcome, amount: number) => void;
}

const TradingTerminal: React.FC<TradingTerminalProps> = ({ market, onTrade }) => {
  const [amount, setAmount] = useState<number>(5);
  const [lastTrade, setLastTrade] = useState<{ outcome: Outcome; amount: number; cost: number } | null>(null);
  const [previewOutcome, setPreviewOutcome] = useState<Outcome | null>(null);

  // Calculate current price for YES (p) and NO (1-p)
  const pYes = getPrice(market.qYes, market.qNo, market.b, 'YES');
  const pNo = 1 - pYes;

  // Calculate trades for both options
  const yesTrade = useMemo(() => 
    calculateTrade('YES', amount, market.qYes, market.qNo, market.b), 
  [market, amount]);
  
  const noTrade = useMemo(() => 
    calculateTrade('NO', amount, market.qYes, market.qNo, market.b), 
  [market, amount]);

  const handleTrade = (outcome: Outcome) => {
    const tradeDetails = outcome === 'YES' ? yesTrade : noTrade;
    onTrade(outcome, amount);
    setLastTrade({
      outcome,
      amount,
      cost: tradeDetails.cost
    });
    setPreviewOutcome(null);
  };

  // Reset last trade when amount changes to show preview again (optional behavior)
  useEffect(() => {
    // We don't necessarily clear lastTrade, but we prioritize preview if hovering
  }, [amount]);

  // Determine what to display in the center: Preview or Last Trade
  const displayData = useMemo(() => {
    if (previewOutcome) {
        const trade = previewOutcome === 'YES' ? yesTrade : noTrade;
        return {
            title: `Buying ${amount} shares of ${previewOutcome}`,
            cost: trade.cost,
            isPreview: true
        };
    }
    if (lastTrade) {
        return {
            title: `You bought ${lastTrade.amount} shares of ${lastTrade.outcome}`,
            cost: lastTrade.cost,
            isPreview: false
        };
    }
    // Default state: Show NO trade preview as per screenshot example or generic
    return {
        title: `Buy ${amount} shares of NO`,
        cost: noTrade.cost,
        isPreview: true
    };
  }, [previewOutcome, lastTrade, yesTrade, noTrade, amount]);

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 rounded-full blur-3xl -z-0 pointer-events-none" />

      {/* Header */}
      <div className="flex justify-between items-start mb-6 relative z-10">
        <div>
          <div className="flex items-center gap-2 text-emerald-400 mb-1">
            <TrendingUp size={16} />
            <span className="text-xs font-bold uppercase tracking-wider">Automated Market Maker</span>
          </div>
          <h2 className="text-2xl font-bold text-white">Liquidity Engine</h2>
        </div>
        <button 
            onClick={() => { setLastTrade(null); setAmount(5); }}
            className="text-slate-600 hover:text-white transition-colors p-2 hover:bg-slate-800 rounded-full"
        >
          <RefreshCw size={20} />
        </button>
      </div>

      {/* Price Bar Section */}
      <div className="relative z-10 mb-8">
        <div className="flex justify-between text-xs font-medium text-slate-400 mb-2 px-1">
            <span>YES Price</span>
            <span>NO Price</span>
        </div>
        
        <div className="h-14 w-full bg-slate-800 rounded-xl overflow-hidden flex relative">
            {/* YES Segment */}
            <div 
                style={{ width: `${pYes * 100}%` }} 
                className="bg-emerald-900/40 border-r border-emerald-500/30 flex items-center pl-4 transition-all duration-500 ease-out"
            >
                <span className="text-xl md:text-2xl font-mono font-bold text-emerald-400">
                    {(pYes * 100).toFixed(1)}%
                </span>
            </div>
            {/* NO Segment */}
            <div className="flex-1 bg-slate-800/50 flex items-center justify-end pr-4">
                <span className="text-xl md:text-2xl font-mono font-bold text-slate-400">
                    {(pNo * 100).toFixed(1)}%
                </span>
            </div>
        </div>
        <div className="text-center text-[10px] text-slate-500 mt-2">
            Current market price. The next user will trade at this rate.
        </div>
      </div>

      {/* Center Cost Display */}
      <div className="text-center mb-8 min-h-[100px] flex flex-col justify-center relative z-10">
        <div className="text-slate-300 mb-1 text-sm font-medium">
            {displayData.title}
        </div>
        <div className="text-4xl font-mono font-bold text-rose-400 mb-2 tracking-tight">
            Cost: ${displayData.cost.toFixed(2)}
        </div>
        <div className="text-xs text-rose-500/80 font-medium">
            Due to slippage, price moves in unfavorable direction
        </div>
      </div>

      {/* Controls */}
      <div className="relative z-10 space-y-4">
        {/* Amount Input */}
        <div className="bg-slate-800/50 rounded-xl p-1 flex items-center border border-slate-700/50">
            <div className="px-4 text-xs font-bold text-slate-500 uppercase tracking-widest">Amount</div>
            <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(Math.max(0.1, parseFloat(e.target.value) || 0))}
                className="flex-1 bg-transparent border-none text-white font-mono text-center outline-none py-2"
            />
            <div className="flex gap-1 pr-1">
                {[1, 5, 10, 50].map(val => (
                <button 
                    key={val}
                    onClick={() => setAmount(val)}
                    className={`px-3 py-1.5 text-[10px] font-bold rounded-lg transition-colors ${amount === val ? 'bg-slate-700 text-white' : 'hover:bg-slate-700/50 text-slate-400'}`}
                >
                    {val}
                </button>
                ))}
            </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-4">
            <button 
                onMouseEnter={() => setPreviewOutcome('YES')}
                onMouseLeave={() => setPreviewOutcome(null)}
                onClick={() => handleTrade('YES')}
                className="group relative py-4 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl flex items-center justify-center gap-2 transition-all active:scale-[0.98] shadow-lg shadow-emerald-900/20"
            >
                Buy YES
                <ArrowUpRight className="w-4 h-4 opacity-50 group-hover:opacity-100 transition-opacity" />
            </button>

            <button 
                onMouseEnter={() => setPreviewOutcome('NO')}
                onMouseLeave={() => setPreviewOutcome(null)}
                onClick={() => handleTrade('NO')}
                className="group relative py-4 bg-transparent border-2 border-slate-700 hover:border-slate-600 text-slate-300 hover:text-white font-bold rounded-xl flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
            >
                Buy NO
                <ArrowUpRight className="w-4 h-4 opacity-50 group-hover:opacity-100 transition-opacity" />
            </button>
        </div>
      </div>
    </div>
  );
};

export default TradingTerminal;
