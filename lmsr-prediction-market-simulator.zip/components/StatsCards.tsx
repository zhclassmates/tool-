
import React from 'react';
import { DollarSign, Droplets, Percent } from 'lucide-react';

interface StatsCardsProps {
  pYes: number;
  b: number;
  currentCost: number;
}

const StatsCards: React.FC<StatsCardsProps> = ({ pYes, b, currentCost }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-lg">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 bg-emerald-500/10 rounded-lg">
            <Percent className="w-4 h-4 text-emerald-500" />
          </div>
          <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">YES Price</span>
        </div>
        <div className="flex items-baseline gap-2">
          <span className="text-2xl font-mono font-bold text-white">{(pYes * 100).toFixed(1)}%</span>
          <span className="text-xs text-slate-500">of $1.00</span>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-lg">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 bg-indigo-500/10 rounded-lg">
            <Droplets className="w-4 h-4 text-indigo-500" />
          </div>
          <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Liquidity Depth</span>
        </div>
        <div className="flex items-baseline gap-2">
          <span className="text-2xl font-mono font-bold text-white">{b.toFixed(0)}</span>
          <span className="text-xs text-slate-500">Param b</span>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-lg">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 bg-amber-500/10 rounded-lg">
            <DollarSign className="w-4 h-4 text-amber-500" />
          </div>
          <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Market Funding</span>
        </div>
        <div className="flex items-baseline gap-2">
          <span className="text-2xl font-mono font-bold text-white">${currentCost.toFixed(2)}</span>
          <span className="text-xs text-slate-500">Total Locked</span>
        </div>
      </div>
    </div>
  );
};

export default StatsCards;
