
import React, { useMemo } from 'react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  ReferenceDot,
  ReferenceLine
} from 'recharts';
import { MarketState } from '../types';
import { calculateCost, getPrice } from '../logic/lmsr';

interface MarketChartsProps {
  market: MarketState;
}

const MarketCharts: React.FC<MarketChartsProps> = ({ market }) => {
  const chartData = useMemo(() => {
    const data = [];
    // We generate the curve by sweeping Probability (Price) from 1% to 99%
    // and calculating the corresponding Cost given the current fixed qNo.
    // This visualizes "The Cost Function Profile" for the YES outcome.
    
    const steps = 100;
    const startP = 0.01;
    const endP = 0.99;

    for (let i = 0; i <= steps; i++) {
      const p = startP + (endP - startP) * (i / steps);
      
      // Calculate qYes required to achieve probability p, given current qNo
      // p = exp(qYes/b) / (exp(qYes/b) + exp(qNo/b))
      // Derived: qYes = qNo - b * ln((1-p)/p)
      const impliedQYes = market.qNo - market.b * Math.log((1 - p) / p);
      
      const cost = calculateCost(impliedQYes, market.qNo, market.b);
      
      data.push({
        prob: (p * 100).toFixed(1), // X-axis key
        pVal: p * 100, // Numeric value for reference
        cost: cost
      });
    }
    return data;
  }, [market]);

  const currentPrice = getPrice(market.qYes, market.qNo, market.b, 'YES') * 100;
  const currentCost = calculateCost(market.qYes, market.qNo, market.b);

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-slate-900 border border-slate-700 p-3 rounded-lg shadow-2xl">
          <p className="text-xs font-bold text-slate-500 uppercase mb-2">Probability: {parseFloat(label).toFixed(0)}%</p>
          <p className="text-sm font-mono text-rose-400">Cost: ${payload[0].value.toFixed(2)}</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="relative w-full h-full">
        <div className="absolute top-4 left-4 z-10 bg-slate-800/80 backdrop-blur px-3 py-1 rounded border border-slate-700">
            <span className="text-xs text-slate-300 font-medium">Cost Function (Logarithmic)</span>
        </div>
        <ResponsiveContainer width="100%" height="100%">
        <LineChart data={chartData} margin={{ top: 20, right: 30, left: 0, bottom: 20 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} opacity={0.5} />
            <XAxis 
            dataKey="pVal" 
            type="number" 
            domain={[0, 100]}
            ticks={[3, 11, 19, 27, 35, 43, 51, 59, 67, 75, 83, 91, 99]}
            stroke="#64748b" 
            fontSize={11} 
            tickFormatter={(val) => `${val}%`}
            tickLine={false}
            axisLine={false}
            dy={10}
            />
            <YAxis 
            stroke="#64748b" 
            fontSize={11}
            tickFormatter={(val) => `${val}`}
            tickLine={false}
            axisLine={false}
            />
            <Tooltip content={<CustomTooltip />} cursor={{ stroke: '#475569', strokeDasharray: '4 4' }} />
            
            <Line
            type="monotone"
            dataKey="cost"
            stroke="#fb7185" // rose-400
            strokeWidth={3}
            dot={false}
            activeDot={{ r: 6, fill: '#f43f5e', stroke: '#fff' }}
            />

            {/* Current Market Position Dot */}
            <ReferenceDot 
                x={currentPrice} 
                y={currentCost} 
                r={5} 
                fill="#fff" 
                stroke="#f43f5e" 
                strokeWidth={2}
                isFront={true}
            />
            <ReferenceLine x={currentPrice} stroke="#475569" strokeDasharray="3 3" />
        </LineChart>
        </ResponsiveContainer>
    </div>
  );
};

export default MarketCharts;
