
import React from 'react';

interface MarketConfigProps {
  b: number;
  initialProb: number;
  onUpdate: (updates: { b?: number; initialProb?: number }) => void;
}

const MarketConfig: React.FC<MarketConfigProps> = ({ b, initialProb, onUpdate }) => {
  return (
    <div className="space-y-8">
      <div>
        <div className="flex justify-between items-center mb-4">
          <label className="text-sm font-medium text-slate-300">Liquidity Parameter (b)</label>
          <span className="px-2 py-1 bg-indigo-500/20 text-indigo-400 text-xs font-mono rounded border border-indigo-500/30">
            {b.toFixed(1)}
          </span>
        </div>
        <input
          type="range"
          min="5"
          max="100"
          step="1"
          value={b}
          onChange={(e) => onUpdate({ b: parseFloat(e.target.value) })}
          className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500"
        />
        <div className="flex justify-between mt-2 text-[10px] text-slate-500 uppercase tracking-widest font-bold">
          <span>High Slippage</span>
          <span>Deep Liquidity</span>
        </div>
      </div>

      <div>
        <div className="flex justify-between items-center mb-4">
          <label className="text-sm font-medium text-slate-300">Target Initial Probability</label>
          <span className="px-2 py-1 bg-emerald-500/20 text-emerald-400 text-xs font-mono rounded border border-emerald-500/30">
            {(initialProb * 100).toFixed(0)}%
          </span>
        </div>
        <input
          type="range"
          min="0.05"
          max="0.95"
          step="0.01"
          value={initialProb}
          onChange={(e) => onUpdate({ initialProb: parseFloat(e.target.value) })}
          className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
        />
        <div className="flex justify-between mt-2 text-[10px] text-slate-500 uppercase tracking-widest font-bold">
          <span>0%</span>
          <span>50%</span>
          <span>100%</span>
        </div>
      </div>
    </div>
  );
};

export default MarketConfig;
