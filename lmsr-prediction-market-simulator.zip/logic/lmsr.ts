
/**
 * LMSR (Logarithmic Market Scoring Rule) Math Core
 * C = b * ln(exp(q1/b) + exp(q2/b))
 */

export const calculateCost = (qYes: number, qNo: number, b: number): number => {
  // Use a stable implementation of log-sum-exp to avoid overflow
  const maxQ = Math.max(qYes, qNo);
  const sum = Math.exp((qYes - maxQ) / b) + Math.exp((qNo - maxQ) / b);
  return maxQ + b * Math.log(sum);
};

export const getPrice = (qYes: number, qNo: number, b: number, outcome: 'YES' | 'NO'): number => {
  const numerator = Math.exp(qYes / b);
  const denominator = Math.exp(qYes / b) + Math.exp(qNo / b);
  const pYes = numerator / denominator;
  return outcome === 'YES' ? pYes : 1 - pYes;
};

export const calculateInitialBias = (targetProb: number, b: number): { qYes: number, qNo: number } => {
  // Solving P = exp(qYes/b) / (exp(qYes/b) + exp(qNo/b))
  // If we set qNo = 0, then P = exp(qYes/b) / (exp(qYes/b) + 1)
  // qYes = b * ln(P / (1 - P))
  if (targetProb <= 0) return { qYes: -100, qNo: 0 }; // Extremes
  if (targetProb >= 1) return { qYes: 100, qNo: 0 };
  
  const qYes = b * Math.log(targetProb / (1 - targetProb));
  return { qYes, qNo: 0 };
};

export const calculateTrade = (
  outcome: 'YES' | 'NO', 
  amount: number, 
  currentQYes: number, 
  currentQNo: number, 
  b: number
): { cost: number, slippage: number } => {
  const oldCost = calculateCost(currentQYes, currentQNo, b);
  const oldPrice = getPrice(currentQYes, currentQNo, b, outcome);
  
  const newQYes = outcome === 'YES' ? currentQYes + amount : currentQYes;
  const newQNo = outcome === 'NO' ? currentQNo + amount : currentQNo;
  
  const newCost = calculateCost(newQYes, newQNo, b);
  const actualCost = newCost - oldCost;
  
  const theoreticalCost = oldPrice * amount;
  const slippage = (actualCost - theoreticalCost) / theoreticalCost;

  return { cost: actualCost, slippage };
};
