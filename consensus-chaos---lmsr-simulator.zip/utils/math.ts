/**
 * Calculates the cost function for the LMSR market maker.
 * C(q) = b * ln(exp(q1/b) + exp(q2/b))
 */
export const calculateCost = (qYes: number, qNo: number, b: number): number => {
  if (b <= 0) return 0;
  // Use log-sum-exp trick if numbers get too large, but for this sim JS floats are likely fine
  return b * Math.log(Math.exp(qYes / b) + Math.exp(qNo / b));
};

/**
 * Calculates the instantaneous price of a share.
 * P_i = exp(q_i / b) / (exp(q1 / b) + exp(q2 / b))
 */
export const calculatePrice = (qInterest: number, qOther: number, b: number): number => {
  if (b <= 0) return 0.5;
  const expInterest = Math.exp(qInterest / b);
  const expOther = Math.exp(qOther / b);
  return expInterest / (expInterest + expOther);
};

/**
 * Calculate the cost to buy a specific amount of shares.
 * Cost = C(q1 + delta, q2) - C(q1, q2)
 */
export const calculateTradeCost = (
  currentYes: number, 
  currentNo: number, 
  b: number, 
  isBuyingYes: boolean, 
  amount: number
): number => {
  const oldCost = calculateCost(currentYes, currentNo, b);
  const newYes = isBuyingYes ? currentYes + amount : currentYes;
  const newNo = !isBuyingYes ? currentNo + amount : currentNo;
  const newCost = calculateCost(newYes, newNo, b);
  return newCost - oldCost;
};

/**
 * Inverse function: Given a probability and b, calculate the required share difference
 * Assuming qNo = 0 for normalization, find qYes.
 * p = e^(qYes/b) / (e^(qYes/b) + 1)
 * qYes = b * ln(p / (1 - p))
 */
export const calculateSharesFromProb = (prob: number, b: number): { qYes: number, qNo: number } => {
  // Avoid division by zero or infinity at 0% or 100%
  const p = Math.max(0.01, Math.min(0.99, prob));
  const qYes = b * Math.log(p / (1 - p));
  return { qYes, qNo: 0 };
};