export interface MarketState {
  sharesYes: number;
  sharesNo: number;
  liquidity: number; // b parameter
}

export enum Outcome {
  YES = 'YES',
  NO = 'NO'
}