import React from 'react';
import { ArrowDown, CheckCircle2, TrendingUp, Scale, Zap } from 'lucide-react';

const InfoPanel: React.FC = () => {
  return (
    <div className="flex flex-col justify-center max-w-2xl">
      <h1 className="text-5xl lg:text-7xl font-bold tracking-tighter mb-6 leading-[1.1]">
        Consensus <br />
        <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-500">
          from Chaos
        </span>
      </h1>
      
      <p className="text-lg text-slate-400 mb-12 leading-relaxed max-w-lg">
        Prediction markets turn individual beliefs into collective truth. Unlike surveys, 
        here you back your opinion with value. The LMSR algorithm ensures there is always a buyer for every seller.
      </p>

      <div className="flex items-center gap-2 text-xs font-mono text-slate-500 mb-12 uppercase tracking-widest">
        <ArrowDown className="w-4 h-4 animate-bounce" />
        Scroll to Learn
      </div>

      <div className="space-y-16">
        <section>
          <h2 className="text-2xl font-semibold text-white mb-6 flex items-center gap-3">
            <Scale className="w-6 h-6 text-blue-400" />
            The Science Behind
          </h2>
          <div className="prose prose-invert text-slate-400">
            <p className="mb-4">
              LMSR (Logarithmic Market Scoring Rule) is a market maker mechanism that ensures 
              continuous liquidity while automatically updating prices based on trading activity.
            </p>
            <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4 font-mono text-sm text-blue-200/80 overflow-x-auto">
              C = b * ln(e^(q1/b) + e^(q2/b))
            </div>
            <p className="text-sm mt-3 text-slate-500">
              The cost function <span className="text-slate-300">C</span> determines the total liquidity. 
              The parameter <span className="text-slate-300">b</span> controls how much the price moves per trade (slippage).
            </p>
          </div>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-white mb-6 flex items-center gap-3">
            <Zap className="w-6 h-6 text-yellow-400" />
            How It Works
          </h2>
          <ul className="space-y-6">
            {[
              { title: "Initialization", desc: "The market starts with a liquidity parameter (b) and an initial probability (usually 50/50)." },
              { title: "Trading", desc: "Traders buy shares of YES or NO. Buying shares increases the price of that outcome and decreases the other." },
              { title: "Price Equilibrium", desc: "The price settles where the marginal trader believes the cost equals the expected value." }
            ].map((step, i) => (
              <li key={i} className="flex gap-4">
                <span className="flex-shrink-0 w-8 h-8 rounded-full bg-slate-800/80 text-blue-400 flex items-center justify-center text-sm font-bold border border-slate-700">
                  {i + 1}
                </span>
                <div>
                  <h4 className="text-white font-medium mb-1">{step.title}</h4>
                  <p className="text-slate-400 text-sm leading-relaxed">{step.desc}</p>
                </div>
              </li>
            ))}
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-white mb-6 flex items-center gap-3">
            <TrendingUp className="w-6 h-6 text-emerald-400" />
            Key Benefits
          </h2>
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="bg-slate-900/30 border border-slate-800 p-5 rounded-2xl hover:bg-slate-900/50 transition-colors">
              <h3 className="text-white font-medium mb-2 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500" /> Continuous Liquidity
              </h3>
              <p className="text-sm text-slate-500 leading-relaxed">
                The Automated Market Maker (AMM) is always willing to trade, ensuring you can enter or exit a position at any time.
              </p>
            </div>
            <div className="bg-slate-900/30 border border-slate-800 p-5 rounded-2xl hover:bg-slate-900/50 transition-colors">
              <h3 className="text-white font-medium mb-2 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500" /> Price Discovery
              </h3>
              <p className="text-sm text-slate-500 leading-relaxed">
                Prices naturally reflect the aggregated information of all participants, often outperforming polls.
              </p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default InfoPanel;