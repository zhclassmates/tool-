import React, { useState } from 'react';
import { RefreshCw, LayoutGrid, RotateCcw, Activity } from 'lucide-react';
import { calculatePrice, calculateTradeCost, calculateSharesFromProb } from '../utils/math';
import Chart from './Chart';

const Simulator: React.FC = () => {
  // Market Parameters
  const [b, setB] = useState<number>(100);
  const [targetProb, setTargetProb] = useState<number>(0.5);
  
  // Market State
  const [sharesYes, setSharesYes] = useState<number>(0);
  const [sharesNo, setSharesNo] = useState<number>(0);
  
  // Trading Interaction
  const [tradeAmount, setTradeAmount] = useState<number>(10);
  const [lastAction, setLastAction] = useState<string | null>(null);

  // Derived Values
  const priceYes = calculatePrice(sharesYes, sharesNo, b);
  const priceNo = calculatePrice(sharesNo, sharesYes, b);
  
  const costYes = calculateTradeCost(sharesYes, sharesNo, b, true, tradeAmount);
  const costNo = calculateTradeCost(sharesYes, sharesNo, b, false, tradeAmount);

  const handleProbChange = (newProb: number) => {
    setTargetProb(newProb);
    const { qYes, qNo } = calculateSharesFromProb(newProb, b);
    setSharesYes(qYes);
    setSharesNo(qNo);
    setLastAction('Reset');
  };

  const handleLiquidityChange = (newB: number) => {
    setB(newB);
  };

  const executeTrade = (isYes: boolean) => {
    if (isYes) {
      setSharesYes(prev => prev + tradeAmount);
      setLastAction(`Bought ${tradeAmount} YES`);
    } else {
      setSharesNo(prev => prev + tradeAmount);
      setLastAction(`Bought ${tradeAmount} NO`);
    }
  };

  return (
    <div className="space-y-4">
      
      {/* 1. Header & Quick Actions */}
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-indigo-400" />
          <h2 className="text-sm font-semibold text-indigo-100 uppercase tracking-wide">Market Console</h2>
        </div>
        <button 
          onClick={() => handleProbChange(0.5)}
          className="text-xs flex items-center gap-1.5 text-slate-500 hover:text-indigo-400 transition-colors px-2 py-1 rounded-md hover:bg-slate-800"
        >
          <RotateCcw className="w-3 h-3" /> Reset
        </button>
      </div>

      {/* 2. Visualizer (Chart) */}
      <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-4 shadow-sm backdrop-blur-sm">
        <div className="flex justify-between items-center mb-1">
          <span className="text-xs font-medium text-slate-400">Price Sensitivity</span>
          <span className="text-[10px] text-slate-600 font-mono">b = {b}</span>
        </div>
        <Chart b={b} currentYes={sharesYes} currentNo={sharesNo} />
      </div>

      {/* 3. Parameter Controls (Compact) */}
      <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-4 space-y-4 shadow-sm">
        
        {/* Liquidity */}
        <div className="space-y-2">
          <div className="flex justify-between items-end">
            <label className="text-xs font-medium text-slate-400">Liquidity (b)</label>
            <span className="text-xs font-mono text-indigo-300 bg-indigo-500/10 px-1.5 rounded">{b}</span>
          </div>
          <input 
            type="range" min="10" max="500" step="10"
            value={b} onChange={(e) => handleLiquidityChange(Number(e.target.value))}
            className="w-full accent-indigo-500 h-1 bg-slate-700 rounded-lg appearance-none cursor-pointer"
          />
        </div>

        {/* Probability */}
        <div className="space-y-2">
          <div className="flex justify-between items-end">
            <label className="text-xs font-medium text-slate-400">Target Prob.</label>
            <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-1.5 rounded">{(targetProb * 100).toFixed(0)}%</span>
          </div>
          <input 
            type="range" min="0.01" max="0.99" step="0.01"
            value={targetProb} onChange={(e) => handleProbChange(Number(e.target.value))}
            className="w-full accent-emerald-500 h-1 bg-slate-700 rounded-lg appearance-none cursor-pointer"
          />
        </div>
      </div>

      {/* 4. Market State (Prices) */}
      <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-4 shadow-sm">
        <div className="flex items-center gap-2 mb-3">
          <LayoutGrid className="w-3.5 h-3.5 text-slate-500" />
          <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Live Prices</span>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="bg-[#0b0f17] border border-slate-800/80 rounded-xl p-3 flex flex-col justify-between relative overflow-hidden">
            <div className="absolute top-0 right-0 p-1.5 opacity-20"><Activity className="w-8 h-8 text-emerald-500" /></div>
            <span className="text-xs text-slate-500 font-medium">YES</span>
            <span className="text-2xl font-bold text-emerald-400 tracking-tight">{(priceYes * 100).toFixed(1)}<span className="text-sm text-emerald-600">%</span></span>
          </div>
          <div className="bg-[#0b0f17] border border-slate-800/80 rounded-xl p-3 flex flex-col justify-between relative overflow-hidden">
            <div className="absolute top-0 right-0 p-1.5 opacity-20"><Activity className="w-8 h-8 text-rose-500" /></div>
            <span className="text-xs text-slate-500 font-medium">NO</span>
            <span className="text-2xl font-bold text-rose-400 tracking-tight">{(priceNo * 100).toFixed(1)}<span className="text-sm text-rose-600">%</span></span>
          </div>
        </div>
      </div>

      {/* 5. Trading Engine */}
      <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-4 shadow-sm">
         <div className="mb-3">
            <div className="flex justify-between items-center mb-2">
              <label className="text-xs font-medium text-slate-400 uppercase tracking-wide">
                Amount
              </label>
              <div className="flex gap-1">
                {[1, 10, 50].map(val => (
                  <button 
                    key={val}
                    onClick={() => setTradeAmount(val)}
                    className={`text-[10px] px-2 py-0.5 rounded border ${tradeAmount === val ? 'bg-slate-700 text-white border-slate-600' : 'border-slate-800 text-slate-500 hover:border-slate-600'} transition-all`}
                  >
                    {val}
                  </button>
                ))}
              </div>
            </div>
            <input 
              type="number" min="1"
              value={tradeAmount}
              onChange={(e) => setTradeAmount(Math.max(1, parseInt(e.target.value) || 0))}
              className="w-full bg-[#0b0f17] border border-slate-700 text-slate-200 px-3 py-2 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono text-center text-sm"
            />
         </div>

         <div className="grid grid-cols-2 gap-3">
           <button 
            onClick={() => executeTrade(true)}
            className="group relative bg-emerald-600 hover:bg-emerald-500 text-white py-3 rounded-lg transition-all active:scale-[0.98] shadow-lg shadow-emerald-900/20"
           >
             <div className="flex flex-col items-center leading-none">
               <span className="font-bold text-sm">Buy YES</span>
               <span className="text-[10px] font-mono opacity-70 mt-1">
                 ${costYes.toFixed(2)}
               </span>
             </div>
           </button>

           <button 
            onClick={() => executeTrade(false)}
            className="group relative bg-rose-600 hover:bg-rose-500 text-white py-3 rounded-lg transition-all active:scale-[0.98] shadow-lg shadow-rose-900/20"
           >
             <div className="flex flex-col items-center leading-none">
               <span className="font-bold text-sm">Buy NO</span>
               <span className="text-[10px] font-mono opacity-70 mt-1">
                 ${costNo.toFixed(2)}
               </span>
             </div>
           </button>
         </div>
         
         {lastAction && (
           <div className="text-center mt-3 text-[10px] text-slate-500 font-mono animate-pulse">
             > {lastAction}
           </div>
         )}
      </div>

    </div>
  );
};

export default Simulator;