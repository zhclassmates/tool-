import React, { useMemo } from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { calculatePrice } from '../utils/math';

interface ChartProps {
  b: number;
  currentYes: number;
  currentNo: number;
}

const Chart: React.FC<ChartProps> = ({ b, currentYes, currentNo }) => {
  const data = useMemo(() => {
    const points = [];
    const range = b * 3; 
    
    for (let i = -range; i <= range; i += (range / 20)) {
      const price = Math.exp(i / b) / (Math.exp(i / b) + 1);
      
      points.push({
        netShares: Math.round(i),
        price: price,
      });
    }
    return points;
  }, [b]);

  const currentPrice = calculatePrice(currentYes, currentNo, b);
  const currentNet = currentYes - currentNo;

  return (
    <div className="w-full h-48 relative -ml-2">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
          <defs>
            <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#818cf8" stopOpacity={0.3}/>
              <stop offset="95%" stopColor="#818cf8" stopOpacity={0}/>
            </linearGradient>
          </defs>
          <XAxis 
            dataKey="netShares" 
            stroke="#334155" 
            tick={{fontSize: 10, fill: '#475569'}}
            tickLine={false}
            axisLine={false}
          />
          <YAxis 
            domain={[0, 1]} 
            stroke="#334155"
            tick={{fontSize: 10, fill: '#475569'}}
            tickLine={false}
            axisLine={false}
            tickFormatter={(val) => `${(val * 100).toFixed(0)}%`}
          />
          <Tooltip 
            contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '6px', fontSize: '12px' }}
            itemStyle={{ color: '#e2e8f0' }}
            labelStyle={{ color: '#94a3b8', marginBottom: '2px' }}
            formatter={(val: number) => [(val * 100).toFixed(1) + '%', 'Prob']}
            labelFormatter={(label) => `Net: ${label}`}
          />
          <Area 
            type="monotone" 
            dataKey="price" 
            stroke="#818cf8" 
            strokeWidth={2}
            fillOpacity={1} 
            fill="url(#colorPrice)" 
          />
          <ReferenceLine x={currentNet} stroke="#22d3ee" strokeDasharray="3 3" opacity={0.5} />
          <ReferenceLine y={currentPrice} stroke="#22d3ee" strokeDasharray="3 3" opacity={0.5} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
};

export default Chart;