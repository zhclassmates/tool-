import React, { useState } from 'react';
import InfoPanel from './components/InfoPanel';
import Simulator from './components/Simulator';
import { Settings2, X } from 'lucide-react';

const App: React.FC = () => {
  const [isMobileSimOpen, setIsMobileSimOpen] = useState(false);

  return (
    <div className="h-full bg-[#020617] text-slate-200 flex flex-col font-sans selection:bg-indigo-500/30">
      {/* Background decoration - Fixed */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-[-10%] right-[-5%] w-[500px] h-[500px] bg-indigo-500/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-[-10%] left-[-10%] w-[600px] h-[600px] bg-emerald-500/5 rounded-full blur-3xl"></div>
      </div>

      {/* Main Layout Grid */}
      <div className="flex-1 flex overflow-hidden w-full relative z-10">
        
        {/* LEFT PANEL: Scrollable Content */}
        <main className="flex-1 overflow-y-auto min-h-0 custom-scrollbar relative">
           <div className="max-w-3xl mx-auto pl-6 pr-6 lg:pl-12 lg:pr-12 pt-12 pb-24">
             <InfoPanel />
             
             {/* Footer inside the scrollable content area */}
             <footer className="mt-20 text-center text-slate-600 text-xs py-8 border-t border-slate-900/50">
               <p>© {new Date().getFullYear()} LMSR Educational Simulator. Built for understanding prediction markets.</p>
             </footer>
           </div>
        </main>

        {/* RIGHT PANEL: Fixed Width Simulator Console (Desktop) */}
        <aside className="hidden lg:block w-[440px] border-l border-slate-800/60 bg-[#020617]/80 backdrop-blur-sm overflow-y-auto min-h-0 custom-scrollbar p-6">
            <Simulator />
        </aside>
      </div>

      {/* MOBILE: Toggle Button */}
      <button
        onClick={() => setIsMobileSimOpen(true)}
        className="lg:hidden fixed bottom-6 right-6 h-14 w-14 bg-indigo-600 hover:bg-indigo-500 text-white rounded-full shadow-xl shadow-indigo-900/40 flex items-center justify-center z-50 transition-transform active:scale-95"
      >
        <Settings2 className="w-6 h-6" />
      </button>

      {/* MOBILE: Drawer/Overlay */}
      {isMobileSimOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex justify-end isolate">
           {/* Backdrop */}
           <div 
             className="absolute inset-0 bg-black/80 backdrop-blur-sm" 
             onClick={() => setIsMobileSimOpen(false)}
           />
           
           {/* Slide-out Panel */}
           <div className="relative w-full max-w-md bg-[#0b0f17] h-full overflow-y-auto shadow-2xl border-l border-slate-800 flex flex-col">
             <div className="sticky top-0 z-10 bg-[#0b0f17]/95 backdrop-blur border-b border-slate-800 p-4 flex justify-between items-center">
               <h2 className="font-bold text-slate-200">Market Simulator</h2>
               <button 
                onClick={() => setIsMobileSimOpen(false)} 
                className="p-2 -mr-2 text-slate-400 hover:text-white rounded-full hover:bg-slate-800"
               >
                 <X className="w-6 h-6" />
               </button>
             </div>
             <div className="p-6">
               <Simulator />
             </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default App;