# UA-OSINT: Dynamic Knowledge Graph & OSINT Tracker

端到端动态知识图谱与开源情报追踪系统。包含贝叶斯共识引擎、红蓝对抗 Agent、SSE 流式推送、力导向图谱渲染与 Flipbook 爆裂卡片。

## 架构概览

```
┌─────────────────┐     SSE      ┌──────────────────┐
│  React Frontend │ ◄─────────── │  FastAPI Backend │
│  Force Graph    │              │  Bayesian Engine │
│  Flipbook Cards │              │  Red-Blue Arena  │
└─────────────────┘              └────────┬─────────┘
                                          │
                                    Redis Stream
                                          │
                              ┌───────────┴───────────┐
                              │   Ingestion Sources   │
                              │   Web / PDF / API     │
                              └───────────────────────┘
```

## 快速启动 (无 Docker)

### 1. 启动后端
```bash
cd backend
pip install -r requirements.txt
python main.py
# 或 uvicorn main:app --reload
```

### 2. 启动前端
```bash
cd frontend
npm install
npm run dev
```

### 3. 注入测试数据
打开前端 `http://localhost:5173`，点击：
- **🔥 Inject Conflict** → 触发 Sam Altman 红蓝对抗
- **✅ Inject Clean** → 触发 Tether 无冲突收敛

## Docker 部署

```bash
docker-compose up --build
```

## API 端点

| 端点 | 方法 | 说明 |
|------|------|------|
| `/health` | GET | 健康检查 |
| `/ingest` | POST | 注入单条情报 |
| `/demo/conflict` | POST | 注入冲突测试数据 |
| `/demo/clean` | POST | 注入干净测试数据 |
| `/api/stream` | GET | SSE 实时流 |

## 核心模块

- `cognitive/bayesian.py` — 多信源贝叶斯融合与冲突检测
- `cognitive/arena.py` — 红蓝对抗 Agent + 法官裁决
- `cognitive/orchestrator.py` — Redis Stream 消费 / SSE 广播编排
- `components/ForceGraph.tsx` — 力导向图谱 (react-force-graph-2d)
- `components/Flipbook.tsx` — 渐进式卡片流
- `components/SSEConnector.tsx` — SSE 连接 + requestAnimationFrame 节流缓冲

## 许可证

MIT
