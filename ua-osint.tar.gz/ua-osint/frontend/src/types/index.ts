export interface GraphNode {
  id: string;
  name: string;
  val: number;
  confidence: number;
  state: string;
  x?: number;
  y?: number;
}

export interface GraphEdge {
  source: string;
  target: string;
  relation: string;
  confidence: number;
  state: string;
}

export interface DebateRound {
  round_num: number;
  red_argument: string;
  blue_argument: string;
  red_score: number;
  blue_score: number;
}

export interface SSEPulse {
  pulse_type: 'entity' | 'edge' | 'debate' | 'verdict' | 'freeze' | 'heartbeat';
  node_id?: string;
  edge_id?: string;
  confidence?: number;
  state?: string;
  payload: Record<string, any>;
  ts: number;
}

export interface FlipCard {
  id: string;
  nodeId: string;
  type: 'red' | 'blue' | 'judge' | 'info';
  title: string;
  content: string;
  confidence?: number;
  timestamp: number;
}
