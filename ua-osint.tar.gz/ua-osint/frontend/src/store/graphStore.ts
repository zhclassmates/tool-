import { create } from 'zustand';
import { GraphNode, GraphEdge, FlipCard } from '../types';

interface GraphState {
  nodes: GraphNode[];
  edges: GraphEdge[];
  cards: FlipCard[];
  selectedNode: string | null;
  addOrUpdateNode: (node: GraphNode) => void;
  addOrUpdateEdge: (edge: GraphEdge) => void;
  addCard: (card: FlipCard) => void;
  removeOldCards: (maxAgeMs: number) => void;
  setSelectedNode: (id: string | null) => void;
  freezeColdNodes: (thresholdMs: number) => void;
}

export const useGraphStore = create<GraphState>((set, get) => ({
  nodes: [],
  edges: [],
  cards: [],
  selectedNode: null,

  addOrUpdateNode: (node) => set((state) => {
    const exists = state.nodes.find((n) => n.id === node.id);
    if (exists) {
      return {
        nodes: state.nodes.map((n) =>
          n.id === node.id ? { ...n, ...node, val: node.val ?? n.val } : n
        ),
      };
    }
    return { nodes: [...state.nodes, node] };
  }),

  addOrUpdateEdge: (edge) => set((state) => {
    const key = `${edge.source}->${edge.target}`;
    const exists = state.edges.find(
      (e) => `${e.source}->${e.target}` === key
    );
    if (exists) {
      return {
        edges: state.edges.map((e) =>
          `${e.source}->${e.target}` === key ? { ...e, ...edge } : e
        ),
      };
    }
    return { edges: [...state.edges, edge] };
  }),

  addCard: (card) => set((state) => ({
    cards: [card, ...state.cards].slice(0, 20),
  })),

  removeOldCards: (maxAgeMs) => set((state) => ({
    cards: state.cards.filter(
      (c) => Date.now() - c.timestamp < maxAgeMs
    ),
  })),

  setSelectedNode: (id) => set({ selectedNode: id }),

  freezeColdNodes: (thresholdMs) => set((state) => ({
    nodes: state.nodes.map((n) =>
      Date.now() - (n as any).__lastUpdate > thresholdMs && n.state !== 'frozen'
        ? { ...n, state: 'frozen', val: Math.max(3, n.val * 0.5) }
        : n
    ),
  })),
}));
