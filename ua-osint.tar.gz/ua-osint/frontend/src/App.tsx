import { useCallback } from 'react';
import ForceGraph from './components/ForceGraph';
import Flipbook from './components/Flipbook';
import SSEConnector from './components/SSEConnector';

export default function App() {
  const injectConflict = useCallback(async () => {
    await fetch('/demo/conflict', { method: 'POST' });
  }, []);

  const injectClean = useCallback(async () => {
    await fetch('/demo/clean', { method: 'POST' });
  }, []);

  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative' }}>
      <SSEConnector />
      <ForceGraph />
      <Flipbook />

      {/* HUD Overlay */}
      <div
        style={{
          position: 'fixed',
          top: 16,
          left: 16,
          zIndex: 100,
          display: 'flex',
          gap: 10,
        }}
      >
        <button
          onClick={injectConflict}
          style={{
            padding: '10px 18px',
            borderRadius: 8,
            border: '1px solid #ff4444',
            background: 'rgba(255,68,68,0.15)',
            color: '#ff8888',
            cursor: 'pointer',
            fontWeight: 600,
            fontSize: 13,
          }}
        >
          🔥 Inject Conflict
        </button>
        <button
          onClick={injectClean}
          style={{
            padding: '10px 18px',
            borderRadius: 8,
            border: '1px solid #00ff88',
            background: 'rgba(0,255,136,0.15)',
            color: '#88ffcc',
            cursor: 'pointer',
            fontWeight: 600,
            fontSize: 13,
          }}
        >
          ✅ Inject Clean
        </button>
      </div>

      <div
        style={{
          position: 'fixed',
          bottom: 16,
          left: 16,
          zIndex: 100,
          fontSize: 12,
          color: '#556677',
        }}
      >
        UA-OSINT v0.1.0 | SSE Stream | Bayesian Consensus | Red-Blue Arena
      </div>
    </div>
  );
}
