import { useEffect } from 'react';
import { useGraphStore } from '../store/graphStore';

const CARD_COLORS: Record<string, string> = {
  red: 'linear-gradient(135deg, #ff4444 0%, #aa0000 100%)',
  blue: 'linear-gradient(135deg, #4488ff 0%, #0022aa 100%)',
  judge: 'linear-gradient(135deg, #ffcc00 0%, #aa8800 100%)',
  info: 'linear-gradient(135deg, #444455 0%, #222233 100%)',
};

export default function Flipbook() {
  const cards = useGraphStore((s) => s.cards);
  const removeOld = useGraphStore((s) => s.removeOldCards);

  useEffect(() => {
    const id = setInterval(() => removeOld(30000), 5000);
    return () => clearInterval(id);
  }, [removeOld]);

  return (
    <div
      style={{
        position: 'fixed',
        right: 20,
        top: 80,
        width: 340,
        maxHeight: '80vh',
        overflowY: 'auto',
        zIndex: 50,
        display: 'flex',
        flexDirection: 'column',
        gap: 10,
        paddingRight: 4,
      }}
    >
      {cards.map((card) => (
        <div
          key={card.id}
          style={{
            background: CARD_COLORS[card.type] || CARD_COLORS.info,
            borderRadius: 12,
            padding: '14px 16px',
            color: '#fff',
            fontSize: 13,
            boxShadow: '0 8px 24px rgba(0,0,0,0.5)',
            border: '1px solid rgba(255,255,255,0.08)',
            animation: 'slideIn 0.4s ease-out',
            backdropFilter: 'blur(10px)',
          }}
        >
          <div style={{ fontWeight: 700, marginBottom: 6, fontSize: 14 }}>
            {card.title}
          </div>
          <div style={{ opacity: 0.9, lineHeight: 1.5 }}>{card.content}</div>
          {card.confidence !== undefined && (
            <div style={{ marginTop: 8, fontSize: 11, opacity: 0.7 }}>
              Confidence: {(card.confidence * 100).toFixed(1)}%
            </div>
          )}
        </div>
      ))}
      <style>{`
        @keyframes slideIn {
          from { opacity: 0; transform: translateX(40px) scale(0.95); }
          to { opacity: 1; transform: translateX(0) scale(1); }
        }
      `}</style>
    </div>
  );
}
