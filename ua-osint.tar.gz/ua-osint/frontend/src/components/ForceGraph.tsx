import { useCallback, useRef, useEffect } from 'react';
import ForceGraph2D from 'react-force-graph-2d';
import { useGraphStore } from '../store/graphStore';

const COLOR_MAP: Record<string, string> = {
  solid: '#00ff88',
  dashed: '#ffaa00',
  swing: '#ff44ff',
  frozen: '#555577',
  rejected: '#ff2222',
};

export default function ForceGraph() {
  const fgRef = useRef<any>(null);
  const nodes = useGraphStore((s) => s.nodes);
  const edges = useGraphStore((s) => s.edges);
  const selected = useGraphStore((s) => s.selectedNode);
  const setSelected = useGraphStore((s) => s.setSelectedNode);

  useEffect(() => {
    if (fgRef.current) {
      fgRef.current.d3Force('charge')?.strength(-300);
      fgRef.current.d3Force('link')?.distance(120);
    }
  }, []);

  const nodeColor = useCallback((n: any) => {
    if (selected === n.id) return '#ffffff';
    return COLOR_MAP[n.state] || '#8899aa';
  }, [selected]);

  const nodeCanvasObject = useCallback((node: any, ctx: CanvasRenderingContext2D, globalScale: number) => {
    const label = node.name || node.id;
    const fontSize = 12 / globalScale;
    ctx.font = `${fontSize}px Sans-Serif`;
    const textWidth = ctx.measureText(label).width;
    const bckgDimensions = [textWidth, fontSize].map((n) => n + fontSize * 0.4);

    ctx.fillStyle = 'rgba(10, 10, 20, 0.8)';
    ctx.beginPath();
    ctx.roundRect(
      node.x - bckgDimensions[0] / 2,
      node.y - bckgDimensions[1] / 2,
      bckgDimensions[0],
      bckgDimensions[1],
      4
    );
    ctx.fill();

    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = nodeColor(node);
    ctx.fillText(label, node.x, node.y);

    // Confidence ring
    if (node.confidence !== undefined) {
      ctx.strokeStyle = nodeColor(node);
      ctx.lineWidth = 2 / globalScale;
      ctx.beginPath();
      ctx.arc(node.x, node.y, (node.val || 10) / globalScale + 4, 0, 2 * Math.PI * node.confidence);
      ctx.stroke();
    }
  }, [nodeColor]);

  return (
    <ForceGraph2D
      ref={fgRef}
      graphData={{ nodes, links: edges }}
      nodeAutoColorBy="state"
      nodeColor={nodeColor}
      nodeVal="val"
      nodeCanvasObject={nodeCanvasObject}
      nodeCanvasObjectMode={() => 'replace'}
      linkColor={(l: any) => COLOR_MAP[l.state] || '#445566'}
      linkWidth={(l: any) => (l.confidence || 0.5) * 3}
      linkDirectionalParticles={2}
      linkDirectionalParticleSpeed={(l: any) => (l.confidence || 0.5) * 0.02}
      backgroundColor="#0a0a0f"
      onNodeClick={(n: any) => setSelected(n.id === selected ? null : n.id)}
      warmupTicks={20}
      cooldownTicks={100}
    />
  );
}
