import { useEffect, useRef } from 'react';
import { useGraphStore } from '../store/graphStore';
import { SSEPulse, FlipCard } from '../types';

const BATCH_MS = 80;

export default function SSEConnector() {
  const bufferRef = useRef<SSEPulse[]>([]);
  const rafRef = useRef<number>(0);
  const addNode = useGraphStore((s) => s.addOrUpdateNode);
  const addEdge = useGraphStore((s) => s.addOrUpdateEdge);
  const addCard = useGraphStore((s) => s.addCard);

  useEffect(() => {
    const evtSource = new EventSource('/api/stream');

    evtSource.onmessage = (event) => {
      try {
        const pulse: SSEPulse = JSON.parse(event.data);
        if (pulse.pulse_type === 'heartbeat') return;
        bufferRef.current.push(pulse);
      } catch (e) {
        console.error('SSE parse error', e);
      }
    };

    const flush = () => {
      const batch = bufferRef.current.splice(0, bufferRef.current.length);
      for (const p of batch) {
        handlePulse(p, addNode, addEdge, addCard);
      }
      rafRef.current = requestAnimationFrame(flush);
    };
    rafRef.current = requestAnimationFrame(flush);

    return () => {
      evtSource.close();
      cancelAnimationFrame(rafRef.current);
    };
  }, [addNode, addEdge, addCard]);

  return null;
}

function handlePulse(
  p: SSEPulse,
  addNode: any,
  addEdge: any,
  addCard: any
) {
  const ts = Date.now();
  const entity = p.payload?.entity as string;

  if (p.pulse_type === 'entity' && p.node_id) {
    addNode({
      id: p.node_id,
      name: entity || p.node_id,
      val: 10 + (p.payload?.claims_count || 1) * 3,
      confidence: 0.5,
      state: 'swing',
    });
  }

  if (p.pulse_type === 'edge' && p.node_id) {
    addEdge({
      source: 'center',
      target: p.node_id,
      relation: 'analyzing',
      confidence: p.confidence ?? 0.5,
      state: p.state || 'dashed',
    });
    addNode({
      id: p.node_id,
      confidence: p.confidence ?? 0.5,
      state: p.state || 'dashed',
    } as any);
  }

  if (p.pulse_type === 'debate' && p.node_id) {
    addCard({
      id: `debate-${p.node_id}-${ts}`,
      nodeId: p.node_id,
      type: 'info',
      title: '🔥 Debate Triggered',
      content: `Conflict detected on ${entity}. Red vs Blue agents engaged.`,
      timestamp: ts,
    });
  }

  if (p.pulse_type === 'verdict' && p.node_id) {
    const winner = p.payload?.winner as string;
    const verdict = p.payload?.verdict as string;
    const reasoning = p.payload?.reasoning as string;

    addNode({
      id: p.node_id,
      confidence: p.confidence ?? 0.5,
      state: p.state || 'dashed',
    } as any);
    addEdge({
      source: 'center',
      target: p.node_id,
      relation: verdict,
      confidence: p.confidence ?? 0.5,
      state: p.state || 'dashed',
    });

    const cardType = winner === 'red' ? 'red' : winner === 'blue' ? 'blue' : 'judge';
    addCard({
      id: `verdict-${p.node_id}-${ts}`,
      nodeId: p.node_id,
      type: cardType,
      title: winner ? `⚖️ Verdict: ${winner.toUpperCase()} wins` : '⚖️ Verdict: Undetermined',
      content: reasoning || 'No reasoning provided.',
      confidence: p.confidence,
      timestamp: ts,
    });

    // Also emit individual debate round cards if available
    const log = p.payload?.debate_log as any[];
    if (log && Array.isArray(log)) {
      log.forEach((round, idx) => {
        addCard({
          id: `round-${p.node_id}-${idx}-${ts}`,
          nodeId: p.node_id,
          type: 'red',
          title: `Red Round ${round.round_num}`,
          content: round.red_argument,
          timestamp: ts,
        });
        addCard({
          id: `roundb-${p.node_id}-${idx}-${ts}`,
          nodeId: p.node_id,
          type: 'blue',
          title: `Blue Round ${round.round_num}`,
          content: round.blue_argument,
          timestamp: ts,
        });
      });
    }
  }
}
