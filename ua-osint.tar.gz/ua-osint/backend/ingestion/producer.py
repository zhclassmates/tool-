"""Ingestion producer: push claims to Redis Stream or memory queue."""
import json
import time
from typing import Optional
from models.schemas import SourceClaim

class IngestionProducer:
    def __init__(self, redis_client=None, stream_key: str = "ua:intel:stream"):
        self.redis = redis_client
        self.stream_key = stream_key

    async def push(self, claim: SourceClaim) -> bool:
        payload = json.dumps(claim.model_dump())
        if self.redis:
            await self.redis.xadd(self.stream_key, {"data": payload})
            return True
        return False

# Demo data generators
def generate_conflict_batch() -> list:
    return [
        SourceClaim(
            claim_id="c001", source="Twitter Rumor", source_tier=4,
            claim="Sam Altman resigned to start a crypto company",
            timestamp=time.time(), raw_confidence=0.25,
            entity="Sam Altman", relation="employment", target="resigned"
        ),
        SourceClaim(
            claim_id="c002", source="OpenAI Blog", source_tier=1,
            claim="Sam Altman announced GPT-5 release schedule",
            timestamp=time.time(), raw_confidence=0.95,
            entity="Sam Altman", relation="employment", target="active_ceo"
        ),
        SourceClaim(
            claim_id="c003", source="Bloomberg", source_tier=2,
            claim="OpenAI board confirms Altman continues as CEO",
            timestamp=time.time(), raw_confidence=0.88,
            entity="Sam Altman", relation="employment", target="active_ceo"
        ),
    ]

def generate_clean_batch() -> list:
    return [
        SourceClaim(
            claim_id="c004", source="SEC Filing", source_tier=1,
            claim="Tether published Q2 reserve audit report",
            timestamp=time.time(), raw_confidence=0.92,
            entity="Tether", relation="audit", target="Q2_report"
        ),
        SourceClaim(
            claim_id="c005", source="Tether Official", source_tier=1,
            claim="Tether Q2 reserve ratio is 105%",
            timestamp=time.time(), raw_confidence=0.90,
            entity="Tether", relation="audit", target="Q2_report"
        ),
    ]
