"""Cognitive orchestrator: ingest → cluster → bayes → debate → SSE emit."""
import asyncio
import hashlib
import json
import time
import logging
from typing import Dict, List, Optional, Any
from collections import defaultdict

from models.schemas import SourceClaim, SSEPulse, EdgeState
from cognitive.bayesian import BayesianConsensusEngine
from cognitive.arena import RedBlueArena

logger = logging.getLogger("ua.orchestrator")

class CognitiveOrchestrator:
    def __init__(self, redis_url: Optional[str] = None, stream_key: str = "ua:intel:stream"):
        self.stream_key = stream_key
        self.group_name = "cognitive_brains"
        self.consumer_name = f"brain-{hashlib.md5(str(time.time()).encode()).hexdigest()[:6]}"
        self.bayes = BayesianConsensusEngine()
        self.arena = RedBlueArena(max_rounds=3)
        self._memory_queue: asyncio.Queue = asyncio.Queue()
        self._redis_client: Optional[Any] = None
        self._sse_subscribers: List[asyncio.Queue] = []
        self._running = False

        if redis_url:
            try:
                import redis.asyncio as redis_lib
                self._redis_client = redis_lib.from_url(redis_url)
                logger.info("Redis client initialized.")
            except Exception as e:
                logger.warning(f"Redis unavailable, using memory queue: {e}")

    async def ingest(self, claim: SourceClaim):
        await self._memory_queue.put(claim)

    def subscribe(self) -> asyncio.Queue:
        q = asyncio.Queue()
        self._sse_subscribers.append(q)
        return q

    async def _emit(self, pulse: SSEPulse):
        for q in self._sse_subscribers:
            await q.put(pulse)
        logger.info(f"[SSE] {pulse.pulse_type} node={pulse.node_id} conf={pulse.confidence} state={pulse.state}")

    async def _read_claims(self) -> List[SourceClaim]:
        claims = []
        if self._redis_client:
            try:
                await self._redis_client.xgroup_create(
                    self.stream_key, self.group_name, id="0", mkstream=True
                )
            except Exception as e:
                if "BUSYGROUP" not in str(e):
                    logger.warning(e)
            entries = await self._redis_client.xreadgroup(
                groupname=self.group_name,
                consumername=self.consumer_name,
                streams={self.stream_key: ">"},
                count=10,
                block=500
            )
            for stream_name, messages in entries:
                for msg_id, fields in messages:
                    payload = {k.decode() if isinstance(k, bytes) else k:
                               v.decode() if isinstance(v, bytes) else v for k, v in fields.items()}
                    claims.append(SourceClaim.model_validate_json(payload["data"]))
                    await self._redis_client.xack(self.stream_key, self.group_name, msg_id)
        else:
            try:
                for _ in range(10):
                    claim = self._memory_queue.get_nowait()
                    claims.append(claim)
            except asyncio.QueueEmpty:
                pass
        return claims

    async def process_cycle(self):
        claims = await self._read_claims()
        if not claims:
            return

        buckets: Dict[str, List[SourceClaim]] = defaultdict(list)
        for c in claims:
            buckets[c.entity or "unknown"].append(c)

        for entity, bucket in buckets.items():
            node_id = f"node:{hashlib.md5(entity.encode()).hexdigest()[:8]}"
            await self._emit(SSEPulse(
                pulse_type="entity",
                node_id=node_id,
                payload={"entity": entity, "claims_count": len(bucket)}
            ))

            self.bayes.reset()
            posterior = self.bayes.update(bucket)

            await self._emit(SSEPulse(
                pulse_type="edge",
                node_id=node_id,
                confidence=round(posterior, 4),
                state=EdgeState.SWING.value if posterior < 0.8 else EdgeState.SOLID.value,
                payload={"history": self.bayes.history}
            ))

            if self.bayes.detect_conflict(bucket):
                await self._emit(SSEPulse(
                    pulse_type="debate",
                    node_id=node_id,
                    state="debate_start",
                    payload={"trigger_claims": [c.model_dump() for c in bucket]}
                ))
                target = min(bucket, key=lambda x: x.raw_confidence)
                verdict = self.arena.debate(target, bucket)
                await self._emit(SSEPulse(
                    pulse_type="verdict",
                    node_id=node_id,
                    confidence=verdict.final_confidence,
                    state=verdict.edge_state.value,
                    payload={
                        "verdict": verdict.verdict,
                        "reasoning": verdict.reasoning,
                        "winner": verdict.winner,
                        "debate_log": [r.model_dump() for r in verdict.debate_log]
                    }
                ))
            else:
                state = EdgeState.SOLID.value if posterior > 0.8 else EdgeState.DASHED.value
                await self._emit(SSEPulse(
                    pulse_type="verdict",
                    node_id=node_id,
                    confidence=round(posterior, 4),
                    state=state,
                    payload={"verdict": "auto_confirmed", "reasoning": "No conflict, Bayesian convergence."}
                ))

    async def run(self):
        self._running = True
        logger.info(f"Orchestrator started | consumer={self.consumer_name}")
        while self._running:
            await self.process_cycle()
            await asyncio.sleep(0.3)

    def stop(self):
        self._running = False
