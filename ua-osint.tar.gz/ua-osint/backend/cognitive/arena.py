"""Red-Blue adversarial agent arena with judge verdict."""
import random
from typing import List, Optional, Literal
from models.schemas import SourceClaim, DebateRound, JudgeVerdict, EdgeState

class RedBlueArena:
    def __init__(self, max_rounds: int = 3):
        self.max_rounds = max_rounds
        random.seed()

    def _red_agent(self, claim: SourceClaim, context: List[SourceClaim], round_num: int) -> str:
        templates = [
            f"[Red#{round_num}] Source '{claim.source}' is Tier-{claim.source_tier} with known misinformation history.",
            f"[Red#{round_num}] Claim lacks direct evidence chain and cannot be cross-verified.",
            f"[Red#{round_num}] Timestamp anomaly: this claim predates official announcement.",
            f"[Red#{round_num}] Entity '{claim.entity}' has no such association in authoritative records.",
        ]
        return random.choice(templates)

    def _blue_agent(self, claim: SourceClaim, context: List[SourceClaim], round_num: int) -> str:
        templates = [
            f"[Blue#{round_num}] Source '{claim.source}' has 92% accuracy on similar claims historically.",
            f"[Blue#{round_num}] Claim is cross-validated by SEC filings / on-chain data.",
            f"[Blue#{round_num}] Time delta is within reasonable propagation window for breaking news.",
            f"[Blue#{round_num}] Entity '{claim.entity}' has indirect corroboration from Reuters/Bloomberg.",
        ]
        return random.choice(templates)

    def _judge_score(self, red_arg: str, blue_arg: str, claim: SourceClaim) -> tuple:
        base_red = random.uniform(0.3, 0.7)
        base_blue = random.uniform(0.3, 0.7)
        if claim.source_tier <= 2:
            base_blue += 0.15
        else:
            base_red += 0.15
        # Content heuristic: if claim contains strong verbs, boost blue
        strong_signals = ["confirmed", "filed", "announced", "verified"]
        if any(s in claim.claim.lower() for s in strong_signals):
            base_blue += 0.08
        return round(min(base_red, 0.95), 3), round(min(base_blue, 0.95), 3)

    def debate(self, target_claim: SourceClaim, context: List[SourceClaim]) -> JudgeVerdict:
        rounds: List[DebateRound] = []
        red_total = 0.0
        blue_total = 0.0

        for i in range(1, self.max_rounds + 1):
            red_arg = self._red_agent(target_claim, context, i)
            blue_arg = self._blue_agent(target_claim, context, i)
            r_score, b_score = self._judge_score(red_arg, blue_arg, target_claim)
            red_total += r_score
            blue_total += b_score
            rounds.append(DebateRound(
                round_num=i,
                red_argument=red_arg,
                blue_argument=blue_arg,
                red_score=r_score,
                blue_score=b_score
            ))

        margin = blue_total - red_total
        if margin > 0.3:
            verdict = "true"
            final_confidence = min(0.95, 0.65 + margin * 0.25)
            edge_state = EdgeState.SOLID
            winner = "blue"
            reasoning = f"Blue wins significantly (margin={margin:.2f}). Source credibility supports the claim."
        elif margin < -0.3:
            verdict = "false"
            final_confidence = max(0.05, 0.35 + margin * 0.25)
            edge_state = EdgeState.REJECTED
            winner = "red"
            reasoning = f"Red wins significantly (margin={margin:.2f}). Critical flaws identified."
        else:
            verdict = "undetermined"
            final_confidence = 0.5
            edge_state = EdgeState.DASHED
            winner = None
            reasoning = f"Dead heat (margin={margin:.2f}). Insufficient evidence to resolve conflict."

        return JudgeVerdict(
            verdict=verdict,
            final_confidence=round(final_confidence, 4),
            reasoning=reasoning,
            edge_state=edge_state,
            winner=winner,
            debate_log=rounds
        )
