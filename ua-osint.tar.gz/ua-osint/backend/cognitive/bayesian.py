"""Bayesian consensus engine for multi-source intelligence fusion."""
import math
from typing import List, Dict
from models.schemas import SourceClaim

class BayesianConsensusEngine:
    def __init__(self, prior: float = 0.5, convergence_threshold: float = 0.02):
        self.prior = prior
        self.convergence_threshold = convergence_threshold
        self.history: List[Dict] = []

    def source_tier_to_likelihood(self, tier: int, claim: str) -> float:
        base = {1: 0.90, 2: 0.80, 3: 0.65, 4: 0.55}.get(tier, 0.5)
        boosters = ["announced", "filed", "confirmed", "official", "verified", "audit"]
        if any(k in claim.lower() for k in boosters):
            base = min(base + 0.05, 0.99)
        return base

    def update(self, claims: List[SourceClaim]) -> float:
        posterior = self.prior
        for c in claims:
            likelihood = self.source_tier_to_likelihood(c.source_tier, c.claim)
            prior_odds = posterior / (1 - posterior)
            likelihood_ratio = likelihood / (1 - likelihood + 1e-9)
            posterior_odds = prior_odds * likelihood_ratio
            posterior = posterior_odds / (1 + posterior_odds)
            posterior = max(0.01, min(0.99, posterior))
            self.history.append({
                "claim_id": c.claim_id,
                "source": c.source,
                "likelihood": round(likelihood, 4),
                "posterior": round(posterior, 4)
            })
        return posterior

    def detect_conflict(self, claims: List[SourceClaim]) -> bool:
        if len(claims) < 2:
            return False
        posterior = self.update(claims)
        tiers = {c.source_tier for c in claims}
        has_high = any(t <= 2 for t in tiers)
        has_low = any(t >= 3 for t in tiers)
        return (posterior < 0.60 and has_high and has_low) or posterior < 0.45

    def reset(self):
        self.prior = 0.5
        self.history.clear()
