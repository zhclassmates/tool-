"""Pydantic schemas for UA-OSINT cognitive pipeline."""
from pydantic import BaseModel, Field
from typing import List, Optional, Literal
from enum import Enum
from datetime import datetime

class ConfidenceLevel(str, Enum):
    CERTAIN = "certain"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    CONFLICT = "conflict"

class EdgeState(str, Enum):
    SOLID = "solid"
    DASHED = "dashed"
    SWING = "swing"
    FROZEN = "frozen"
    REJECTED = "rejected"

class SourceClaim(BaseModel):
    claim_id: str
    source: str
    source_tier: int = Field(ge=1, le=4, description="1=authority, 4=anonymous")
    claim: str
    timestamp: float
    raw_confidence: float = 0.5
    entity: Optional[str] = None
    relation: Optional[str] = None
    target: Optional[str] = None

class DebateRound(BaseModel):
    round_num: int
    red_argument: str
    blue_argument: str
    red_score: float
    blue_score: float

class JudgeVerdict(BaseModel):
    verdict: Literal["true", "false", "undetermined"]
    final_confidence: float
    reasoning: str
    edge_state: EdgeState
    winner: Optional[Literal["red", "blue"]] = None
    debate_log: List[DebateRound] = []
    timestamp: float = Field(default_factory=datetime.now().timestamp)

class SSEPulse(BaseModel):
    pulse_type: Literal["entity", "edge", "debate", "verdict", "freeze"]
    node_id: Optional[str] = None
    edge_id: Optional[str] = None
    confidence: Optional[float] = None
    state: Optional[str] = None
    payload: dict = Field(default_factory=dict)
    ts: float = Field(default_factory=datetime.now().timestamp)

class GraphNode(BaseModel):
    id: str
    name: str
    val: int = 10
    confidence: float = 0.5
    state: str = "dashed"
    x: Optional[float] = None
    y: Optional[float] = None

class GraphEdge(BaseModel):
    source: str
    target: str
    relation: str = "related"
    confidence: float = 0.5
    state: str = "dashed"
