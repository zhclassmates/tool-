"""UA-OSINT FastAPI backend with SSE streaming."""
import asyncio
import json
import logging
from contextlib import asynccontextmanager
from typing import AsyncGenerator

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sse_starlette.sse import EventSourceResponse

from models.schemas import SourceClaim
from cognitive.orchestrator import CognitiveOrchestrator
from ingestion.producer import IngestionProducer, generate_conflict_batch, generate_clean_batch

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(name)s] %(levelname)s: %(message)s")
logger = logging.getLogger("ua.api")

# Global orchestrator instance
orch: CognitiveOrchestrator = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    global orch
    redis_url = "redis://localhost:6379/0"
    orch = CognitiveOrchestrator(redis_url=redis_url)
    task = asyncio.create_task(orch.run())
    logger.info("Orchestrator background task started.")
    yield
    orch.stop()
    task.cancel()
    logger.info("Shutdown complete.")

app = FastAPI(title="UA-OSINT Cognitive API", version="0.1.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
async def health():
    return {"status": "ok", "consumer": orch.consumer_name if orch else None}

@app.post("/ingest")
async def ingest_claim(claim: SourceClaim):
    await orch.ingest(claim)
    return {"status": "queued", "claim_id": claim.claim_id}

@app.post("/demo/conflict")
async def demo_conflict():
    for c in generate_conflict_batch():
        await orch.ingest(c)
    return {"status": "injected_conflict", "count": 3}

@app.post("/demo/clean")
async def demo_clean():
    for c in generate_clean_batch():
        await orch.ingest(c)
    return {"status": "injected_clean", "count": 2}

async def sse_generator() -> AsyncGenerator[str, None]:
    q = orch.subscribe()
    try:
        while True:
            pulse = await asyncio.wait_for(q.get(), timeout=30.0)
            yield pulse.model_dump_json()
    except asyncio.TimeoutError:
        yield json.dumps({"pulse_type": "heartbeat", "ts": asyncio.get_event_loop().time()})

@app.get("/api/stream")
async def stream():
    return EventSourceResponse(sse_generator(), media_type="text/event-stream")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
