// LMSR (Logarithmic Market Scoring Rule) Utilities

// Clamps a number between min and max
export function clamp(x: number, min: number, max: number) {
  return Math.max(min, Math.min(max, x));
}

// Cost Function: C = b * ln(e^(qYes/b) + e^(qNo/b))
export function lmsrCost(b: number, qYes: number, qNo: number) {
  const a = qYes / b;
  const c = qNo / b;
  const m = Math.max(a, c); // Log-sum-exp trick to prevent overflow
  return b * (m + Math.log(Math.exp(a - m) + Math.exp(c - m)));
}

// Price Function: P(Yes) = e^(qYes/b) / (e^(qYes/b) + e^(qNo/b))
export function priceYes(b: number, qYes: number, qNo: number) {
  const a = qYes / b;
  const c = qNo / b;
  const m = Math.max(a, c);
  const ey = Math.exp(a - m);
  const en = Math.exp(c - m);
  return ey / (ey + en);
}

// Inverse Function: Calculate qYes needed to reach target probability p
// Assuming qNo is fixed at 0 for the slider demo context
export function qFromP(b: number, p: number) {
  const pp = clamp(p, 0.001, 0.999);
  // Derived from P = e^q / (e^q + 1) -> q = ln(P / (1-P)) * b
  return b * Math.log(pp / (1 - pp));
}