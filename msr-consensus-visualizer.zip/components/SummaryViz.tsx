import React, { useEffect, useState, useRef } from 'react';
import { ResponsiveContainer, LineChart, Line, YAxis, XAxis, ReferenceLine, Tooltip } from 'recharts';
import { Target } from 'lucide-react';

interface DataPoint {
  time: number;
  value: number;
}

export const SummaryViz: React.FC = () => {
  const [data, setData] = useState<DataPoint[]>([]);
  const [isConverged, setIsConverged] = useState(false);
  const frameRef = useRef<number>(0);
  const startTimeRef = useRef<number>(Date.now());

  // Simulation Parameters
  const TRUE_VALUE = 0.75; // The "Truth" the market finds
  const INITIAL_VOLATILITY = 0.4;
  const DECAY_RATE = 0.98; // How fast volatility drops
  
  useEffect(() => {
    let currentValue = 0.5; // Start at 50%
    let currentVolatility = INITIAL_VOLATILITY;
    let timeStep = 0;
    const newData: DataPoint[] = [];

    // Reset
    setData([{ time: 0, value: 0.5 }]);
    setIsConverged(false);

    const animate = () => {
      // 1. Calculate next price (Random Walk with Mean Reversion + Decay)
      const noise = (Math.random() - 0.5) * currentVolatility;
      // Slight pull towards true value (informed traders entering)
      const pull = (TRUE_VALUE - currentValue) * 0.05; 
      
      currentValue = currentValue + noise + pull;
      // Clamp
      currentValue = Math.max(0.1, Math.min(0.9, currentValue));
      
      // 2. Decay volatility (Liquidity increases, spreads tighten)
      currentVolatility *= DECAY_RATE;

      timeStep++;
      newData.push({ time: timeStep, value: currentValue });
      
      // Keep only last 50 points for performance, but we want to show full history here for "convergence"
      // Let's cap at 100 points then stop
      if (timeStep < 80) {
        setData([...newData]);
        frameRef.current = requestAnimationFrame(animate);
      } else {
        setIsConverged(true);
      }
    };

    frameRef.current = requestAnimationFrame(animate);

    return () => cancelAnimationFrame(frameRef.current);
  }, []); // Run once on mount

  return (
    <div className="flex flex-col h-full p-6">
      <div className="flex justify-between items-start mb-6">
        <div>
          <div className="flex items-center gap-2 text-cyan-400 mb-1">
            <Target size={18} />
            <span className="font-bold uppercase tracking-wider text-xs">Market Equilibrium</span>
          </div>
          <h3 className="text-xl font-bold text-slate-100">Convergence to Truth</h3>
        </div>
        
        {isConverged && (
            <button 
                onClick={() => {
                   // Force re-mount or logic to restart. 
                   // Simple way: just reload the component by parent, but here we can't easily.
                   // We'll let the user scroll away and back to reset in this simple scrollytelling setup.
                }}
                className="text-xs bg-slate-800 text-slate-400 px-2 py-1 rounded animate-pulse"
            >
                Consensus Reached
            </button>
        )}
      </div>

      <div className="flex-1 relative bg-slate-950/50 rounded-xl border border-slate-800 overflow-hidden">
        
        {/* Graph */}
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 20, right: 20, left: -20, bottom: 0 }}>
             <defs>
                <linearGradient id="lineColor" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stopColor="#f43f5e" />
                    <stop offset="50%" stopColor="#a78bfa" />
                    <stop offset="100%" stopColor="#22d3ee" />
                </linearGradient>
            </defs>
            <YAxis domain={[0, 1]} hide />
            <XAxis dataKey="time" hide />
            <ReferenceLine y={TRUE_VALUE} stroke="#22d3ee" strokeDasharray="3 3" opacity={0.5} label={{ value: "TRUE VALUE", fill: "#22d3ee", fontSize: 10, position: "insideBottomRight" }} />
            
            <Line 
                type="monotone" 
                dataKey="value" 
                stroke="url(#lineColor)" 
                strokeWidth={3} 
                dot={false}
                animationDuration={0} // We handle animation via state updates
            />
          </LineChart>
        </ResponsiveContainer>

        {/* Overlay Explanations */}
        <div className="absolute top-4 left-4 space-y-2 pointer-events-none">
            <div className={`transition-all duration-500 ${data.length < 20 ? 'opacity-100 translate-x-0' : 'opacity-20 -translate-x-4'}`}>
                <span className="text-xs font-bold text-rose-400 bg-rose-950/30 px-2 py-1 rounded border border-rose-900/50">High Volatility</span>
                <p className="text-[10px] text-slate-500 mt-1 max-w-[120px]">Low liquidity, high uncertainty.</p>
            </div>
        </div>

        <div className="absolute bottom-4 right-4 space-y-2 pointer-events-none text-right">
            <div className={`transition-all duration-500 ${isConverged ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-4'}`}>
                <span className="text-xs font-bold text-cyan-400 bg-cyan-950/30 px-2 py-1 rounded border border-cyan-900/50">Equilibrium</span>
                <p className="text-[10px] text-slate-500 mt-1">Marginal cost of information exceeds potential profit.</p>
            </div>
        </div>

      </div>

      <div className="mt-6 p-4 bg-slate-900/50 border border-slate-800 rounded-lg text-sm text-slate-400">
          As more traders participate, they correct the price and add liquidity. The volatility dampens, and the price converges on the collective <strong>Best Estimate</strong>.
      </div>
    </div>
  );
};