import React, { useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  ReferenceDot
} from "recharts";
import { lmsrCost, priceYes, qFromP } from "../utils/math";
import { Scale, Info } from "lucide-react";

export const CostDemo: React.FC = () => {
  const [b, setB] = useState(10);
  const [pTarget, setPTarget] = useState(0.7);

  // Initial state: 50% probability (qYes=0, qNo=0)
  const qNo = 0;
  const qYes0 = 0;
  
  // Calculate qYes required to reach pTarget
  const qYes1 = useMemo(() => qFromP(b, pTarget), [b, pTarget]);

  // Calculate costs
  const cost0 = useMemo(() => lmsrCost(b, qYes0, qNo), [b]);
  const cost1 = useMemo(() => lmsrCost(b, qYes1, qNo), [b, qYes1]);
  const deltaCost = cost1 - cost0;

  // Calculate prices (sanity check)
  const p0 = useMemo(() => priceYes(b, qYes0, qNo), [b]);
  const p1 = useMemo(() => priceYes(b, qYes1, qNo), [b, qYes1]);

  // Generate curve data: "Cost to move probability to X"
  const curve = useMemo(() => {
    const rows = [];
    for (let i = 1; i < 100; i += 2) {
      const p = i / 100;
      const q = qFromP(b, p);
      const dc = lmsrCost(b, q, 0) - cost0;
      rows.push({ p, cost: dc });
    }
    return rows;
  }, [b, cost0]);

  return (
    <div className="flex flex-col h-full p-6">
       <div className="flex justify-between items-start mb-6">
        <div>
          <div className="flex items-center gap-2 text-rose-400 mb-1">
            <Scale size={18} />
            <span className="font-bold uppercase tracking-wider text-xs">Cost Principle</span>
          </div>
          <h3 className="text-xl font-bold text-slate-100">Prediction with a Price</h3>
        </div>
      </div>

      <div className="flex-1 min-h-[200px] relative bg-slate-950/50 rounded-xl border border-slate-800 mb-6 overflow-hidden">
        <div className="absolute top-4 left-4 z-10 bg-slate-900/80 backdrop-blur px-3 py-1 rounded border border-slate-700 text-xs text-slate-400">
           Cost Function (Logarithmic)
        </div>
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={curve} margin={{ top: 20, right: 20, bottom: 20, left: 0 }}>
            <XAxis 
                dataKey="p" 
                tickFormatter={(v) => `${Math.round(v * 100)}%`} 
                stroke="#475569"
                tick={{fill: '#64748b', fontSize: 10}}
            />
            <YAxis 
                stroke="#475569"
                tick={{fill: '#64748b', fontSize: 10}}
                width={40}
            />
            <Tooltip
              contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#f1f5f9' }}
              formatter={(value: any) => [`$${Number(value).toFixed(2)}`, "Cost"]}
              labelFormatter={(label: any) => `Prob: ${Math.round(Number(label) * 100)}%`}
            />
            <Line 
                type="monotone" 
                dataKey="cost" 
                stroke="#f43f5e" 
                strokeWidth={3} 
                dot={false} 
            />
            {/* Current Position Marker */}
            <ReferenceDot x={pTarget} y={deltaCost} r={6} fill="#fff" stroke="#f43f5e" strokeWidth={3} />
            <ReferenceLine x={0.5} stroke="#334155" strokeDasharray="3 3" />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="space-y-6">
        {/* Slider Controls */}
        <div>
            <div className="flex justify-between text-sm mb-2">
                <span className="text-slate-400">Target Probability</span>
                <span className="font-mono text-cyan-400 font-bold">{(pTarget * 100).toFixed(0)}%</span>
            </div>
            <input
                type="range"
                min={1}
                max={99}
                step={1}
                value={Math.round(pTarget * 100)}
                onChange={(e) => setPTarget(Number(e.target.value) / 100)}
                className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500 hover:accent-cyan-400 transition-all"
            />
        </div>

        <div>
            <div className="flex justify-between text-sm mb-2">
                <span className="text-slate-400">Liquidity Parameter (b)</span>
                <span className="font-mono text-slate-300">{b}</span>
            </div>
            <input
                type="range"
                min={2}
                max={50}
                step={1}
                value={b}
                onChange={(e) => setB(Number(e.target.value))}
                className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-slate-500 hover:accent-slate-400 transition-all"
            />
            <div className="text-xs text-slate-500 mt-1">Higher b = Less volatile prices (Lower cost to move)</div>
        </div>

        {/* Stats Box */}
        <motion.div
          key={`${b}-${pTarget}`}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-slate-800/50 p-4 rounded-xl border border-slate-700 flex items-center justify-between"
        >
          <div>
              <div className="text-xs text-slate-500 uppercase">Consensus Shift</div>
              <div className="text-slate-200 font-mono text-sm">
                  {(p0 * 100).toFixed(0)}% <span className="text-slate-500">→</span> <span className="text-cyan-400 font-bold">{(p1 * 100).toFixed(1)}%</span>
              </div>
          </div>
          <div className="text-right">
              <div className="text-xs text-slate-500 uppercase">Cost to Pay</div>
              <div className="text-xl font-bold font-mono text-rose-400">
                  ${deltaCost.toFixed(2)}
              </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};