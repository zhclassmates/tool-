import React, { useEffect, useRef, useState } from 'react';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  bias: number;
}

export const HeroViz: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [hovered, setHovered] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let particles: Particle[] = [];
    
    // Create more particles for better visual density
    const initParticles = () => {
      particles = [];
      for (let i = 0; i < 80; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          vx: (Math.random() - 0.5) * 3, // Faster
          vy: (Math.random() - 0.5) * 3,
          bias: Math.random() * 0.08 + 0.02 // Stronger pull
        });
      }
    };

    const handleResize = () => {
      const parent = canvas.parentElement;
      if (parent) {
        // Handle High DPI displays
        const dpr = window.devicePixelRatio || 1;
        canvas.width = parent.clientWidth * dpr;
        canvas.height = parent.clientHeight * dpr;
        ctx.scale(dpr, dpr);
        canvas.style.width = `${parent.clientWidth}px`;
        canvas.style.height = `${parent.clientHeight}px`;
        initParticles();
      }
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    const render = () => {
      const width = canvas.width / (window.devicePixelRatio || 1);
      const height = canvas.height / (window.devicePixelRatio || 1);
      
      ctx.clearRect(0, 0, width, height);

      // 1. Draw "Truth Curve" (The Attractor)
      const centerY = height / 2;
      ctx.beginPath();
      // Draw a sine wave
      for(let x = 0; x < width; x+=5) {
          const y = centerY + Math.sin((x / width) * Math.PI * 2) * 40;
          if(x===0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
      }
      
      // Glow effect for the line
      ctx.shadowBlur = hovered ? 5 : 20;
      ctx.shadowColor = hovered ? "rgba(244, 63, 94, 0.2)" : "rgba(34, 211, 238, 0.8)";
      ctx.strokeStyle = hovered ? "rgba(244, 63, 94, 0.1)" : "rgba(34, 211, 238, 0.5)"; 
      ctx.lineWidth = 4;
      ctx.stroke();
      ctx.shadowBlur = 0; // Reset

      // 2. Update Particles
      const targetY = (x: number) => {
         const t = x / width;
         return centerY + Math.sin(t * Math.PI * 2) * 40; 
      };

      particles.forEach(p => {
        // Physics
        if (hovered) {
            // Chaos mode: Scatter away from mouse or just random
            p.x += p.vx * 2;
            p.y += p.vy * 2;
        } else {
            // Order mode: Move towards the sine wave
            p.x += p.vx * 0.5; // Maintain some forward momentum
            const idealY = targetY(p.x);
            p.y += (idealY - p.y) * p.bias; // Lerp towards line
        }

        // Wrap around
        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;
        if (p.y < 0) p.y = height;
        if (p.y > height) p.y = 0;

        // Draw Particle
        ctx.beginPath();
        const size = hovered ? Math.random() * 4 + 2 : 3;
        ctx.arc(p.x, p.y, size, 0, Math.PI * 2);
        
        // Color shift
        if (hovered) {
             ctx.fillStyle = `rgba(244, 63, 94, ${Math.random() * 0.5 + 0.5})`; // Red/Rose for Chaos
        } else {
             ctx.fillStyle = `rgba(34, 211, 238, ${Math.random() * 0.5 + 0.5})`; // Cyan for Order
        }
        ctx.fill();
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [hovered]);

  return (
    <div 
      className="w-full h-full flex flex-col items-center justify-center relative cursor-crosshair"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />
      
      <div className={`absolute pointer-events-none transition-all duration-500 flex flex-col items-center ${hovered ? 'scale-110 opacity-100' : 'scale-100 opacity-80'}`}>
          <div className={`text-4xl font-black uppercase tracking-widest backdrop-blur-sm px-4 py-2 rounded-xl ${hovered ? 'text-rose-500 bg-rose-950/20' : 'text-cyan-400 bg-cyan-950/20'}`}>
            {hovered ? "Noise" : "Consensus"}
          </div>
          <div className="text-xs text-slate-400 mt-2 font-mono bg-slate-900/50 px-2 py-1 rounded">
             {hovered ? "Individual Opinions (Scattered)" : "Market Equilibrium (Converged)"}
          </div>
      </div>
      
      {/* Interaction Hint */}
      <div className="absolute bottom-6 text-xs text-slate-500 animate-pulse">
        Hover to disrupt
      </div>
    </div>
  );
};