import React from 'react';

interface SectionProps {
  id?: string;
  title: string;
  description?: string;
  children: React.ReactNode;
  isHero?: boolean;
}

export const Section: React.FC<SectionProps> = ({ id, title, description, children, isHero = false }) => {
  return (
    <section 
      id={id}
      className={`relative w-full flex flex-col md:flex-row ${isHero ? 'min-h-[90vh]' : 'min-h-screen'} border-b border-white/5 overflow-hidden`}
    >
      {/* Content Side - Scrolls normally */}
      <div className={`w-full md:w-1/2 flex flex-col justify-center p-8 md:p-20 z-10 ${isHero ? 'order-2 md:order-1' : 'order-2 md:order-1'}`}>
        <div className="max-w-xl">
           <div className="w-12 h-1 bg-cyan-500 mb-8 rounded-full shadow-[0_0_15px_rgba(6,182,212,0.5)]"></div>
           <h2 className={`text-4xl md:text-6xl font-black leading-tight tracking-tight mb-8 ${isHero ? 'text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-500 to-indigo-500' : 'text-slate-100'}`}>
            {title}
          </h2>
          {description && (
            <p className="text-lg md:text-xl text-slate-400 leading-relaxed font-light pl-6 border-l-2 border-slate-800">
              {description}
            </p>
          )}
        </div>
      </div>

      {/* Visual Side - Sticky on Desktop to keep focus */}
      <div className={`w-full md:w-1/2 h-[60vh] md:h-screen md:sticky md:top-0 flex items-center justify-center p-4 md:p-12 ${isHero ? 'order-1 md:order-2' : 'order-1 md:order-2 bg-slate-900/20'}`}>
        <div className="relative w-full aspect-square max-h-[600px] bg-slate-900/80 backdrop-blur-xl border border-white/10 rounded-3xl shadow-2xl overflow-hidden ring-1 ring-white/5 flex flex-col">
           {children}
           
           {/* Background decorative glows */}
           <div className="absolute -top-32 -right-32 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none mix-blend-screen" />
           <div className="absolute -bottom-32 -left-32 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none mix-blend-screen" />
        </div>
      </div>
    </section>
  );
};