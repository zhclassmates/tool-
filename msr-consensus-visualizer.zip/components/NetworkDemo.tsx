import React, { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { CloudRain, Car, Bitcoin, Zap } from "lucide-react";
import { clamp } from "../utils/math";

export const NetworkDemo: React.FC = () => {
  const [pA, setPA] = useState(0.2); // Rain Probability
  
  // Logic: B is dependent on A, C is independent
  // P(Traffic) = 0.2 (base) + 0.7 * P(Rain)
  const pB = useMemo(() => clamp(0.2 + 0.7 * pA, 0.01, 0.99), [pA]);
  const pC = 0.55; // Bitcoin stays constant

  // Coordinates for nodes relative to container (assuming 300x300 viewBox for SVG)
  const posA = { x: 50, y: 150 };
  const posB = { x: 250, y: 80 };
  const posC = { x: 250, y: 220 };

  return (
    <div className="flex flex-col h-full p-6">
       <div className="flex justify-between items-start mb-6">
        <div>
          <div className="flex items-center gap-2 text-blue-400 mb-1">
            <Zap size={18} />
            <span className="font-bold uppercase tracking-wider text-xs">Bayesian Locality</span>
          </div>
          <h3 className="text-xl font-bold text-slate-100">Smart Updating</h3>
        </div>
      </div>

      <div className="flex-1 relative border border-slate-800 bg-slate-900/30 rounded-xl overflow-hidden">
          {/* SVG CONNECTIONS */}
          <svg className="absolute inset-0 w-full h-full" viewBox="0 0 300 300" preserveAspectRatio="xMidYMid meet">
              <defs>
                  <marker id="arrow" markerWidth="10" markerHeight="10" refX="20" refY="3" orient="auto" markerUnits="strokeWidth">
                    <path d="M0,0 L0,6 L9,3 z" fill="#475569" />
                  </marker>
                  <linearGradient id="activeGradient" gradientUnits="userSpaceOnUse">
                      <stop offset="0%" stopColor="#3b82f6" />
                      <stop offset="100%" stopColor="#f97316" />
                  </linearGradient>
              </defs>

              {/* Edge A -> B (Active) */}
              <motion.path 
                d={`M ${posA.x} ${posA.y} C ${posA.x + 100} ${posA.y}, ${posB.x - 100} ${posB.y}, ${posB.x} ${posB.y}`}
                fill="none"
                stroke={pA > 0.4 ? "url(#activeGradient)" : "#334155"}
                strokeWidth={pA > 0.4 ? 4 : 2}
                markerEnd="url(#arrow)"
                animate={{ strokeDasharray: pA > 0.4 ? [0, 0] : [5, 5] }}
                transition={{ duration: 0.5 }}
              />

              {/* Edge A -> C (Inactive/Weak) */}
              <path 
                d={`M ${posA.x} ${posA.y} C ${posA.x + 100} ${posA.y}, ${posC.x - 100} ${posC.y}, ${posC.x} ${posC.y}`}
                fill="none"
                stroke="#1e293b"
                strokeWidth="2"
                strokeDasharray="5 5"
              />
              
              {/* Data Flow Particle for A->B */}
              {pA > 0.3 && (
                 <circle r="4" fill="#60a5fa">
                    <animateMotion 
                        dur={`${2 - pA}s`} 
                        repeatCount="indefinite" 
                        path={`M ${posA.x} ${posA.y} C ${posA.x + 100} ${posA.y}, ${posB.x - 100} ${posB.y}, ${posB.x} ${posB.y}`}
                    />
                 </circle>
              )}
          </svg>

          {/* NODES (Absolute positioned divs for easier styling) */}
          
          {/* Node A: Rain */}
          <div 
            className="absolute -translate-x-1/2 -translate-y-1/2 w-24 flex flex-col items-center gap-2"
            style={{ left: `${(posA.x / 300) * 100}%`, top: `${(posA.y / 300) * 100}%` }}
          >
             <motion.div 
                className="w-16 h-16 rounded-2xl bg-slate-800 border-2 flex items-center justify-center shadow-xl z-10"
                animate={{ borderColor: pA > 0.5 ? '#3b82f6' : '#475569', scale: 1 + pA * 0.1 }}
             >
                 <CloudRain size={24} className={pA > 0.5 ? 'text-blue-400' : 'text-slate-500'} />
             </motion.div>
             <div className="bg-slate-900/80 backdrop-blur px-2 py-1 rounded text-xs font-mono border border-slate-700">
                 Rain {(pA * 100).toFixed(0)}%
             </div>
          </div>

          {/* Node B: Traffic */}
          <div 
            className="absolute -translate-x-1/2 -translate-y-1/2 w-24 flex flex-col items-center gap-2"
            style={{ left: `${(posB.x / 300) * 100}%`, top: `${(posB.y / 300) * 100}%` }}
          >
             <motion.div 
                className="w-16 h-16 rounded-2xl bg-slate-800 border-2 border-slate-700 flex items-center justify-center shadow-xl z-10"
                animate={{ borderColor: pB > 0.5 ? '#f97316' : '#475569', y: pA > 0.5 ? [0, -5, 0] : 0 }}
             >
                 <Car size={24} className={pB > 0.5 ? 'text-orange-400' : 'text-slate-500'} />
             </motion.div>
             <div className="bg-slate-900/80 backdrop-blur px-2 py-1 rounded text-xs font-mono border border-slate-700 text-orange-200">
                 Traffic {(pB * 100).toFixed(0)}%
             </div>
          </div>

          {/* Node C: Bitcoin */}
          <div 
            className="absolute -translate-x-1/2 -translate-y-1/2 w-24 flex flex-col items-center gap-2 grayscale opacity-60"
            style={{ left: `${(posC.x / 300) * 100}%`, top: `${(posC.y / 300) * 100}%` }}
          >
             <div className="w-16 h-16 rounded-2xl bg-slate-800 border-2 border-slate-700 flex items-center justify-center shadow-xl z-10">
                 <Bitcoin size={24} className="text-yellow-500" />
             </div>
             <div className="bg-slate-900/80 backdrop-blur px-2 py-1 rounded text-xs font-mono border border-slate-700">
                 BTC {(pC * 100).toFixed(0)}%
             </div>
          </div>
      </div>

      <div className="mt-6">
          <div className="flex justify-between text-sm mb-2">
              <span className="text-slate-300 font-bold">Input: Rain Probability</span>
              <span className="font-mono text-blue-400">{(pA * 100).toFixed(0)}%</span>
          </div>
          <input
            type="range"
            min={1}
            max={99}
            step={1}
            value={Math.round(pA * 100)}
            onChange={(e) => setPA(Number(e.target.value) / 100)}
            className="w-full h-3 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500 hover:accent-blue-400 transition-all"
          />
          <p className="text-xs text-slate-500 mt-3 bg-slate-800 p-2 rounded">
              Note: Changing <span className="text-blue-400">Rain</span> automatically updates <span className="text-orange-400">Traffic</span> probability, but <span className="text-slate-400">Bitcoin</span> remains unaffected.
          </p>
      </div>
    </div>
  );
};