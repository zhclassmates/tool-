import React, { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { lmsrCost, priceYes } from "../utils/math";
import { TrendingUp, RefreshCcw } from "lucide-react";

export const LiquidityDemo: React.FC = () => {
  const [b, setB] = useState(20);
  const [k, setK] = useState(5); // Shares to buy per click
  const [qYes, setQYes] = useState(0);
  const [qNo, setQNo] = useState(0);
  const [lastTrade, setLastTrade] = useState<{ side: "YES" | "NO"; delta: number } | null>(null);

  // Current Math
  const cost = useMemo(() => lmsrCost(b, qYes, qNo), [b, qYes, qNo]);
  const pYes = useMemo(() => priceYes(b, qYes, qNo), [b, qYes, qNo]);
  const pNo = 1 - pYes;

  const trade = (side: "YES" | "NO") => {
    const beforeCost = lmsrCost(b, qYes, qNo);
    const ny = side === "YES" ? qYes + k : qYes;
    const nn = side === "NO" ? qNo + k : qNo;
    const afterCost = lmsrCost(b, ny, nn);
    const delta = afterCost - beforeCost;

    setQYes(ny);
    setQNo(nn);
    setLastTrade({ side, delta });
  };

  const handleReset = () => {
      setQYes(0);
      setQNo(0);
      setLastTrade(null);
  };

  return (
    <div className="flex flex-col h-full p-6">
       <div className="flex justify-between items-start mb-6">
        <div>
          <div className="flex items-center gap-2 text-emerald-400 mb-1">
            <TrendingUp size={18} />
            <span className="font-bold uppercase tracking-wider text-xs">Automated Market Maker</span>
          </div>
          <h3 className="text-xl font-bold text-slate-100">Liquidity Engine</h3>
        </div>
        <button 
            onClick={handleReset}
            className="p-2 hover:bg-slate-800 rounded-lg text-slate-500 transition-colors"
            title="Reset Market"
        >
            <RefreshCcw size={18} />
        </button>
      </div>

      <div className="flex-1 flex flex-col justify-center">
          
          {/* PRICE BAR / METER */}
          <div className="mb-8">
              <div className="flex justify-between text-xs text-slate-400 mb-2 font-mono">
                  <span>YES PRICE</span>
                  <span>NO PRICE</span>
              </div>
              <div className="h-16 bg-slate-900 rounded-2xl border border-slate-800 relative overflow-hidden flex">
                  {/* YES PORTION */}
                  <motion.div 
                    className="h-full bg-emerald-500/20 relative border-r border-emerald-500/50"
                    animate={{ width: `${pYes * 100}%` }}
                    transition={{ type: "spring", bounce: 0.2 }}
                  >
                      <div className="absolute inset-0 flex items-center justify-start pl-4 text-emerald-400 font-bold font-mono text-xl">
                          {(pYes * 100).toFixed(1)}%
                      </div>
                  </motion.div>

                  {/* NO PORTION */}
                  <motion.div 
                    className="h-full bg-slate-800/50 relative flex-1"
                  >
                      <div className="absolute inset-0 flex items-center justify-end pr-4 text-slate-500 font-bold font-mono text-xl">
                          {(pNo * 100).toFixed(1)}%
                      </div>
                  </motion.div>
              </div>
              
              <div className="mt-2 text-center text-xs text-slate-500">
                  Current Market Price. The next user will trade at this rate.
              </div>
          </div>

          {/* TRADE LOG */}
          <div className="h-24 flex flex-col items-center justify-center">
              <AnimatePresence mode="wait">
                  {lastTrade ? (
                      <motion.div
                        key={`${qYes}-${qNo}`}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0 }}
                        className="text-center"
                      >
                          <div className="text-sm text-slate-300">
                              You bought <span className="font-bold text-white">{k} shares</span> of {lastTrade.side}
                          </div>
                          <div className="text-2xl font-bold text-rose-400 font-mono mt-1">
                              Cost: ${lastTrade.delta.toFixed(2)}
                          </div>
                          <div className="text-xs text-rose-500/70 mt-1">
                              Price moved against you due to slippage
                          </div>
                      </motion.div>
                  ) : (
                      <div className="text-slate-600 text-sm">Make a trade to see the impact</div>
                  )}
              </AnimatePresence>
          </div>

      </div>

      {/* CONTROLS */}
      <div className="grid grid-cols-2 gap-4 mt-auto">
          <button
            onClick={() => trade("YES")}
            className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-4 rounded-xl shadow-lg shadow-emerald-900/40 active:scale-95 transition-all"
          >
            Buy YES
          </button>
          <button
            onClick={() => trade("NO")}
            className="bg-slate-700 hover:bg-slate-600 text-slate-200 font-bold py-4 rounded-xl shadow-lg active:scale-95 transition-all"
          >
            Buy NO
          </button>
      </div>
      
      <div className="mt-6 space-y-4 border-t border-slate-800 pt-4">
        <div>
            <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-500">Trade Size (k)</span>
                <span className="text-slate-300">{k} shares</span>
            </div>
            <input type="range" min="1" max="20" value={k} onChange={e => setK(Number(e.target.value))} className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-slate-500" />
        </div>
        <div>
            <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-500">Liquidity (b)</span>
                <span className="text-slate-300">{b}</span>
            </div>
            <input type="range" min="5" max="50" value={b} onChange={e => setB(Number(e.target.value))} className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-slate-500" />
        </div>
      </div>

    </div>
  );
};