import React, { useEffect, useRef, useState, useMemo } from 'react';
import { HeroViz } from './components/HeroViz';
import { CostDemo } from './components/CostDemo';
import { LiquidityDemo } from './components/LiquidityDemo';
import { NetworkDemo } from './components/NetworkDemo';
import { SummaryViz } from './components/SummaryViz';
import { BrainCircuit, ArrowDown } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';

type StepId = "hero" | "msr" | "amm" | "graph" | "summary";

// Hook to track visible section
function useActiveStep(stepIds: StepId[]) {
  const [active, setActive] = useState<StepId>("hero");
  const refs = useRef<Record<string, HTMLElement | null>>({});

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        // Sort by how much is visible
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio);
        
        if (visible.length > 0) {
           const targetId = (visible[0].target as HTMLElement).dataset.stepid as StepId;
           if(targetId) setActive(targetId);
        }
      },
      { rootMargin: "-20% 0px -20% 0px", threshold: [0.2, 0.5, 0.8] }
    );

    stepIds.forEach((id) => {
        const el = refs.current[id];
        if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, [stepIds]);

  const setRef = (id: StepId) => (el: HTMLElement | null) => {
    refs.current[id] = el;
  };

  return { active, setRef };
}

const App: React.FC = () => {
  const steps: StepId[] = useMemo(() => ["hero", "msr", "amm", "graph", "summary"], []);
  const { active, setRef } = useActiveStep(steps);

  return (
    <main className="w-full min-h-screen bg-slate-950 text-slate-200 font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 px-6 py-4 flex items-center justify-between backdrop-blur-md bg-slate-950/80 border-b border-white/5">
        <div className="flex items-center gap-2 font-bold text-lg tracking-tight">
          <BrainCircuit className="text-cyan-400" />
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-indigo-400">
            MSR Consensus
          </span>
        </div>
      </header>

      <div className="w-full max-w-[1600px] mx-auto flex flex-col lg:flex-row relative">
          
          {/* LEFT: Text Content (Scrollable) */}
          <div className="w-full lg:w-1/2 p-6 md:p-12 lg:p-24 flex flex-col gap-[20vh] z-10 pt-[20vh]">
              
              <section ref={setRef("hero")} data-stepid="hero" className="min-h-[60vh] flex flex-col justify-center">
                  <div className="w-16 h-1 bg-cyan-500 mb-8 rounded-full shadow-[0_0_15px_rgba(6,182,212,0.5)]"></div>
                  <h1 className="text-5xl md:text-7xl font-black leading-tight tracking-tight mb-6 text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-500 to-indigo-500">
                      Consensus from Chaos
                  </h1>
                  <p className="text-xl md:text-2xl text-slate-400 leading-relaxed font-light">
                      Prediction markets turn individual beliefs into collective truth. 
                      Unlike surveys, here you back your opinion with value.
                  </p>
                  <div className="mt-12 flex items-center gap-2 text-slate-500 animate-bounce">
                      <ArrowDown size={20} />
                      <span className="text-sm uppercase tracking-widest">Scroll to learn</span>
                  </div>
              </section>

              <section ref={setRef("msr")} data-stepid="msr" className="min-h-[80vh] flex flex-col justify-center">
                  <h2 className="text-3xl md:text-5xl font-bold text-slate-100 mb-6">
                      1. Costly Predictions
                  </h2>
                  <p className="text-lg text-slate-400 leading-relaxed mb-6 border-l-2 border-slate-800 pl-6">
                      This is the <strong>Logarithmic Market Scoring Rule (LMSR)</strong>. 
                      You move the consensus probability by buying shares. 
                      The further you push the probability away from the current state, 
                      the exponentially higher the cost.
                  </p>
                  <p className="text-slate-500">
                      This forces you to stop exactly where your confidence ends and your risk aversion begins.
                  </p>
              </section>

              <section ref={setRef("amm")} data-stepid="amm" className="min-h-[80vh] flex flex-col justify-center">
                  <h2 className="text-3xl md:text-5xl font-bold text-slate-100 mb-6">
                      2. Automated Liquidity
                  </h2>
                  <p className="text-lg text-slate-400 leading-relaxed mb-6 border-l-2 border-slate-800 pl-6">
                      No counterparty needed. The algorithm acts as an always-on <strong>Market Maker</strong>.
                  </p>
                  <p className="text-lg text-slate-400 leading-relaxed">
                      As you buy "YES", the price of "YES" automatically increases for the next person. 
                      This ensures that prices (probabilities) always reflect the current demand.
                  </p>
              </section>

              <section ref={setRef("graph")} data-stepid="graph" className="min-h-[80vh] flex flex-col justify-center">
                  <h2 className="text-3xl md:text-5xl font-bold text-slate-100 mb-6">
                      3. Modular Logic
                  </h2>
                  <p className="text-lg text-slate-400 leading-relaxed mb-6 border-l-2 border-slate-800 pl-6">
                      Real world events are connected. If the probability of rain goes up, 
                      traffic jam probability should automatically adjust.
                  </p>
                  <p className="text-lg text-slate-400 leading-relaxed">
                      LMSR handles these dependencies while keeping unrelated events (like Bitcoin price) strictly independent.
                  </p>
              </section>

              <section ref={setRef("summary")} data-stepid="summary" className="min-h-[60vh] flex flex-col justify-center">
                   <h2 className="text-4xl font-bold text-white mb-6">
                        The Truth is the Equilibrium
                    </h2>
                    <p className="text-slate-400 text-lg leading-relaxed mb-8">
                        When no one is willing to pay the cost to change the probability any further, 
                        we know we have reached the collective best guess.
                    </p>
                    <button className="self-start bg-white text-slate-950 hover:bg-cyan-400 font-bold py-4 px-8 rounded-full transition-colors">
                        Launch Market
                    </button>
              </section>

          </div>

          {/* RIGHT: Visual Stage (Sticky) */}
          <div className="hidden lg:flex w-1/2 h-screen sticky top-0 items-center justify-center p-12 bg-slate-900/10">
              <div className="relative w-full aspect-square max-h-[600px] bg-slate-950 backdrop-blur-xl border border-white/10 rounded-3xl shadow-2xl overflow-hidden ring-1 ring-white/5 flex flex-col">
                  {/* Background decoration */}
                  <div className="absolute -top-1/2 -right-1/2 w-full h-full bg-cyan-500/10 rounded-full blur-[100px] pointer-events-none" />
                  
                  <div className="flex-1 relative z-10">
                    <AnimatePresence mode="wait">
                        {active === "hero" && (
                            <motion.div 
                                key="hero"
                                initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                                className="w-full h-full"
                            >
                                <HeroViz />
                            </motion.div>
                        )}
                        {active === "msr" && (
                            <motion.div 
                                key="msr"
                                initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}
                                className="w-full h-full"
                            >
                                <CostDemo />
                            </motion.div>
                        )}
                        {active === "amm" && (
                            <motion.div 
                                key="amm"
                                initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}
                                className="w-full h-full"
                            >
                                <LiquidityDemo />
                            </motion.div>
                        )}
                        {active === "graph" && (
                            <motion.div 
                                key="graph"
                                initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}
                                className="w-full h-full"
                            >
                                <NetworkDemo />
                            </motion.div>
                        )}
                        {active === "summary" && (
                            <motion.div 
                                key="summary"
                                initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}
                                className="w-full h-full"
                            >
                                <SummaryViz />
                            </motion.div>
                        )}
                    </AnimatePresence>
                  </div>
              </div>
          </div>
          
          {/* Mobile floating indicator (simplified for small screens) */}
          <div className="lg:hidden fixed bottom-6 right-6 z-50 bg-slate-800 border border-slate-700 p-2 rounded-full shadow-lg">
             <div className="text-xs font-mono px-2 text-cyan-400">{active.toUpperCase()}</div>
          </div>
      </div>
    </main>
  );
};

export default App;