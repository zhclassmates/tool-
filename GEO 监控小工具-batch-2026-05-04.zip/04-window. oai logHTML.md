# window. oai logHTML

- Provider: ChatGPT
- Source URL: https://chatgpt.com/g/g-p-69e9d6cf79ec81918b5c98867d6b9b74/c/69f07f4a-7478-83ea-9307-e0a0c94c8bb1
- Exported At: 2026-05-04T12:45:11.207Z
- Message Count: 1

---

## 1. unknown

window.__oai_logHTML?window.__oai_logHTML():window.__oai_SSR_HTML=window.__oai_SSR_HTML||Date.now();requestAnimationFrame((function(){window.__oai_logTTI?window.__oai_logTTI():window.__oai_SSR_TTI=window.__oai_SSR_TTI||Date.now()}))
