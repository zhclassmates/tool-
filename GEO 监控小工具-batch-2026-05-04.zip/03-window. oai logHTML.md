# window. oai logHTML

- Provider: ChatGPT
- Source URL: https://chatgpt.com/g/g-p-69e9d6cf79ec81918b5c98867d6b9b74/c/69e9d70a-3188-83ea-945f-1a6740f570d4
- Exported At: 2026-05-04T12:43:38.139Z
- Message Count: 1

---

## 1. unknown

window.__oai_logHTML?window.__oai_logHTML():window.__oai_SSR_HTML=window.__oai_SSR_HTML||Date.now();requestAnimationFrame((function(){window.__oai_logTTI?window.__oai_logTTI():window.__oai_SSR_TTI=window.__oai_SSR_TTI||Date.now()}))
