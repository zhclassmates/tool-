import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import axios from "axios";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Import the engine components
// Using raw imports for server-side logic in this example
import { BirdeyeService } from "./src/services/birdeye.server.ts";
import { traceService } from "./src/services/trace.server.ts";
import { syncService } from "./src/services/sync.server.ts";
import { TagPipeline } from "./src/engine/pipeline.ts";
import { TetlockEngine } from "./src/engine/tetlock.ts";

// In-memory history for MVP
const scanHistory: any[] = [];

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  app.get("/api/history", (req, res) => {
    res.json(scanHistory.slice(-10).reverse());
  });

  app.get("/api/analyze/:address", async (req, res) => {
    const { address } = req.params;
    const apiKey = process.env.BIRDEYE_API_KEY;

    if (!apiKey) {
      return res.status(500).json({ error: "BIRDEYE_API_KEY not configured" });
    }

    try {
      const client = new BirdeyeService(apiKey);
      const pipeline = new TagPipeline();
      const engine = new TetlockEngine(0.85); // Initial base rate

      // Fetch base data
      const realFeatures = await client.getGodviewFeatures(address);
      
      if (!realFeatures || Object.keys(realFeatures).length === 0) {
        return res.status(404).json({ error: "Token data not found on Birdeye" });
      }

      // Deep Forensics (only if HELIUS_API_KEY is available)
      if (process.env.HELIUS_API_KEY) {
        const topTraders = await client.fetchTopTraders(address, 20);
        const traderAddresses = topTraders.map((t: any) => t.address);
        
        const [fundingResults, syncResults] = await Promise.all([
          traceService.verifyFundingChain(traderAddresses),
          syncService.getSlotDistribution(address, traderAddresses)
        ]);

        realFeatures.forensics = {
          isSameFunder: fundingResults.isSameFunder,
          hasBlockSync: syncResults.hasBlockSync,
          sharedJitoTipAccount: syncResults.sharedJitoTipAccount,
          evidence: {
            funderMap: fundingResults.funderMap,
            syncClusters: syncResults.syncGroups,
          }
        };
      }

      const { tags, likelihoodRatio } = pipeline.evaluate(realFeatures);
      const finalProb = engine.calculateProbability(likelihoodRatio);

      const analysis = {
        address,
        features: realFeatures,
        tags,
        probability: finalProb,
        timestamp: new Date().toISOString()
      };

      // Add to history
      scanHistory.push(analysis);
      if (scanHistory.length > 50) scanHistory.shift();

      res.json(analysis);
    } catch (error: any) {
      console.error("Analysis error:", error.message);
      res.status(500).json({ error: "Internal analysis failure", message: error.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
