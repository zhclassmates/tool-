import { useState, useEffect, useRef, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShieldAlert, 
  ShieldCheck, 
  Activity, 
  Search, 
  Crosshair,
  AlertTriangle,
  Zap,
  Info,
  History,
  Terminal,
  FileText,
  Download,
  Share2,
  ExternalLink,
  ChevronRight,
  Fingerprint,
  Lock,
  Eye,
  Server
} from 'lucide-react';
import { 
  Radar, 
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell
} from 'recharts';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

import { ForensicsReport } from './components/ForensicsReport';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface AnalysisResult {
  address: string;
  features: {
    symbol: string;
    is_freeze_revoked: boolean;
    lp_burned_ratio: number;
    volume_24h: number;
    age_hours: number;
    smart_money_buyers_count: number;
    price_to_cost_ratio: number;
    top_10_ratio: number;
    dev_sold_all: boolean;
    forensics?: {
      isSameFunder: boolean;
      hasBlockSync: boolean;
      sharedJitoTipAccount: boolean;
      evidence: {
        funderMap: Record<string, string[]>;
        syncClusters: Array<{ slot: number; count: number; addresses: string[] }>;
      };
    };
  };
  tags: string[];
  probability: number;
  timestamp: string;
}

export default function App() {
  const [address, setAddress] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [logs, setLogs] = useState<string[]>([]);
  const [history, setHistory] = useState<AnalysisResult[]>([]);
  const [showReport, setShowReport] = useState(false);
  const logEndRef = useRef<HTMLDivElement>(null);

  const fetchHistory = async () => {
    try {
      const res = await fetch('/api/history');
      if (res.ok) {
        const data = await res.json();
        setHistory(data);
      }
    } catch (e) {
      console.error("Failed to fetch history");
    }
  };

  useEffect(() => {
    fetchHistory();
    const interval = setInterval(fetchHistory, 10000);
    return () => clearInterval(interval);
  }, []);

  const addLog = (msg: string) => {
    setLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${msg}`].slice(-10));
  };

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const analyzeToken = async (targetAddress?: string) => {
    const searchAddr = targetAddress || address;
    if (!searchAddr.trim()) return;
    
    setLoading(true);
    setError(null);
    setResult(null);
    setLogs([]);
    setShowReport(false);
    
    addLog(`Initiating tactical scan for ${searchAddr.slice(0, 8)}...`);
    
    try {
      addLog("Querying global liquidity nodes...");
      addLog("Deep Forensics: Analyzing funding chains...");
      addLog("Deep Forensics: Scanning Slot synchronization...");
      
      const response = await fetch(`/api/analyze/${searchAddr}`);
      const data = await response.json();
      
      if (!response.ok) {
        if (response.status === 404) {
          throw new Error("Token not found. It may be too new for the global index.");
        }
        throw new Error(data.error || "Uplink Failed");
      }
      
      addLog("Extracting physical behavior markers...");
      addLog("Cross-referencing forensic fingerprints...");
      addLog("Updating Bayesian risk model...");
      
      setTimeout(() => {
        setResult(data);
        addLog(`Analysis finalized for ${data.features.symbol}`);
        setLoading(false);
      }, 1200);

    } catch (err: any) {
      setError(err.message);
      addLog(`ERR: ${err.message}`);
      setLoading(false);
    }
  };

  const chartData = useMemo(() => {
    if (!result) return [];
    return [
      { subject: 'Liquidity', value: result.features.lp_burned_ratio * 100 },
      { subject: 'Security', value: result.features.is_freeze_revoked ? 100 : 0 },
      { subject: 'Whales', value: Math.min(result.features.smart_money_buyers_count * 20, 100) },
      { subject: 'Decentralization', value: (1 - result.features.top_10_ratio) * 100 },
      { subject: 'Volume', value: Math.min(result.features.volume_24h / 10000, 100) },
    ];
  }, [result]);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-indigo-100 selection:text-indigo-900">
      {/* Premium Navigation */}
      <nav className="fixed top-0 left-0 right-0 h-16 bg-white/80 backdrop-blur-xl border-b border-slate-200 z-50">
        <div className="max-w-7xl mx-auto px-6 h-full flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center text-white shadow-lg shadow-indigo-200">
              <Fingerprint className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-lg font-extrabold tracking-tight">GodView <span className="text-indigo-600">Audit</span></h1>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold text-slate-400 font-mono tracking-wider uppercase">Version 2.0 // Private Access</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-6">
            <div className="hidden md:flex items-center gap-4 text-xs font-semibold text-slate-500 uppercase tracking-widest border-r border-slate-200 pr-6">
              <span className="flex items-center gap-1.5"><Server className="w-3 h-3" /> Core: Active</span>
              <span className="flex items-center gap-1.5"><Lock className="w-3 h-3" /> Nodes: Secure</span>
            </div>
            <button className="text-slate-400 hover:text-slate-600 transition-colors">
              <Activity className="w-5 h-5" />
            </button>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-6 pt-32 pb-20">
        {/* Search Header */}
        <section className="max-w-3xl mx-auto text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl font-black text-slate-900 mb-6 tracking-tight leading-tight"
          >
            Tactical Rug-Pull Intelligence <br />
            <span className="text-indigo-600">On-Chain Risk Quantification</span>
          </motion.h2>
          
          <div className="relative group">
            <input 
              type="text" 
              placeholder="Paste Token Contract Address..."
              className="w-full bg-white border-2 border-slate-200 rounded-2xl py-6 px-8 text-lg font-medium shadow-xl shadow-slate-200/50 focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-600 transition-all outline-none"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && analyzeToken()}
            />
            <button 
              onClick={() => analyzeToken()}
              disabled={loading}
              className="absolute right-3 top-3 bottom-3 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-200 text-white font-bold px-8 rounded-xl flex items-center gap-2 shadow-lg shadow-indigo-600/20 active:scale-95 transition-all"
            >
              {loading ? <Activity className="w-5 h-5 animate-spin" /> : <Search className="w-5 h-5" />}
              {loading ? "SEARCHING..." : "ANALYZE"}
            </button>
          </div>
        </section>

        {/* Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Main Results Area */}
          <div className="lg:col-span-12">
            <AnimatePresence mode="wait">
              {loading && <LoadingStub />}
              {error && <ErrorStub message={error} retry={() => analyzeToken()} />}
              
              {result && !loading && (
                <div className="space-y-8">
                  {/* Summary Card */}
                  <div className="bg-white rounded-[2.5rem] p-10 border border-slate-200 shadow-2xl relative overflow-hidden group">
                    <div className="absolute top-0 right-0 p-8">
                       <div className={cn(
                         "px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] flex items-center gap-2",
                         result.probability > 0.7 ? "bg-red-50 text-red-600 border border-red-100" : "bg-emerald-50 text-emerald-600 border border-emerald-100"
                       )}>
                         <span className={cn("w-1.5 h-1.5 rounded-full", result.probability > 0.7 ? "bg-red-600" : "bg-emerald-600")} />
                         High Confidence Verdict
                       </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 items-center">
                      <div className="space-y-6">
                        <div className="space-y-1">
                          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Calculated Risk Index</p>
                          <h3 className={cn(
                            "text-8xl font-black tracking-tighter",
                            result.probability > 0.7 ? "text-red-600" : "text-indigo-600"
                          )}>
                            {(result.probability * 100).toFixed(0)}%
                          </h3>
                        </div>
                        <div className="flex gap-3">
                          <button 
                            onClick={() => setShowReport(true)}
                            className="bg-indigo-600 hover:bg-slate-900 text-white font-bold py-3 px-6 rounded-xl text-sm flex items-center gap-2 transition-all shadow-xl shadow-indigo-100"
                          >
                            <FileText className="w-4 h-4" /> View Detailed Dossier
                          </button>
                        </div>
                      </div>

                      <div className="lg:col-span-2 grid grid-cols-2 lg:grid-cols-4 gap-6">
                        <StatBox label="Token" value={result.features.symbol} />
                        <StatBox label="Markets" value="$SOL / DEX" />
                        <StatBox label="Burn Status" value={`${(result.features.lp_burned_ratio * 100).toFixed(0)}%`} danger={result.features.lp_burned_ratio < 0.5} />
                        <StatBox label="Markers" value={result.tags.length.toString()} />
                      </div>
                    </div>

                    <div className="mt-12 h-2 bg-slate-100 rounded-full overflow-hidden">
                       <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${result.probability * 100}%` }}
                        className={cn("h-full transition-all duration-1000", result.probability > 0.7 ? "bg-red-600" : "bg-indigo-600")}
                       />
                    </div>
                  </div>

                  {/* Secondary Insights */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                     <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-xl space-y-6">
                        <h4 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
                           <Activity className="w-4 h-4 text-indigo-600" /> Statistical Risk Vector
                        </h4>
                        <div className="h-[280px]">
                           <ResponsiveContainer width="100%" height="100%">
                              <BarChart data={chartData} layout="vertical" margin={{ left: 40, right: 20 }}>
                                 <XAxis type="number" hide domain={[0, 100]} />
                                 <YAxis dataKey="subject" type="category" tick={{ fontSize: 10, fontWeight: 700, fill: '#64748b' }} axisLine={false} tickLine={false} />
                                 <Tooltip cursor={{ fill: '#f8fafc' }} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} />
                                 <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={20}>
                                    {chartData.map((entry, index) => (
                                      <Cell key={`cell-${index}`} fill={entry.value < 50 ? '#ef4444' : '#4f46e5'} />
                                    ))}
                                 </Bar>
                              </BarChart>
                           </ResponsiveContainer>
                        </div>
                     </div>

                     <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-xl flex flex-col">
                        <h4 className="font-extrabold text-sm text-slate-900 flex items-center gap-2 mb-6">
                           <History className="w-4 h-4 text-indigo-600" /> Recent Surveillance history
                        </h4>
                        <div className="flex-1 space-y-3 overflow-y-auto max-h-[300px] scrollbar-hide">
                           {history.slice(0, 5).map((item, i) => (
                             <div 
                              key={i} 
                              onClick={() => analyzeToken(item.address)}
                              className="group p-4 bg-slate-50 hover:bg-indigo-50 border border-slate-100 rounded-2xl cursor-pointer transition-all flex items-center justify-between"
                             >
                               <div className="flex items-center gap-3">
                                  <div className="w-8 h-8 rounded-lg bg-teal-500/10 text-teal-600 flex items-center justify-center font-bold text-xs uppercase">
                                     {item.features.symbol.slice(0,1)}
                                  </div>
                                  <div>
                                     <div className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors uppercase">{item.features.symbol}</div>
                                     <div className="text-[10px] font-mono text-slate-400">{item.address.slice(0, 16)}...</div>
                                  </div>
                               </div>
                               <div className={cn("text-xs font-black", item.probability > 0.7 ? "text-red-500" : "text-indigo-600")}>
                                  {(item.probability * 100).toFixed(0)}%
                               </div>
                             </div>
                           ))}
                        </div>
                     </div>
                  </div>
                </div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </main>

      {/* Dossier Report Modal */}
      <AnimatePresence>
        {showReport && result && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-950/60 backdrop-blur-md"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-white w-full max-w-4xl h-[90vh] rounded-[2rem] shadow-[0_35px_60px_-15px_rgba(0,0,0,0.3)] flex flex-col overflow-hidden relative"
            >
               {/* Document Header */}
               <div className="p-10 border-b border-slate-200 flex justify-between items-start bg-slate-50">
                  <div className="space-y-2">
                     <div className="flex items-center gap-3 text-indigo-600">
                        <ShieldAlert className="w-6 h-6" />
                        <span className="text-xs font-black uppercase tracking-[0.3em]">Confidential Risk Dossier</span>
                     </div>
                     <h2 className="text-4xl font-extrabold text-slate-900 tracking-tight uppercase">{result.features.symbol} Analysis Report</h2>
                     <p className="text-slate-500 font-mono text-xs">Target ID: {result.address} | Timestamp: {result.timestamp}</p>
                  </div>
                  <button 
                    onClick={() => setShowReport(false)}
                    className="p-3 bg-slate-200/50 hover:bg-slate-200 rounded-full transition-colors"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </button>
               </div>

               {/* Document Content */}
               <div className="flex-1 overflow-y-auto p-12 space-y-12">
                  
                  {/* Physical Fingerprints Section */}
                  {result.features.forensics?.evidence && (
                    <div className="space-y-6">
                      <SectionTitle title="Physical Evidence (Deep Forensics)" />
                      <div className="bg-slate-950 p-10 rounded-[2.5rem] border border-slate-900 overflow-hidden">
                        <ForensicsReport evidence={result.features.forensics.evidence} />
                      </div>
                    </div>
                  )}

                  {/* Executive Summary Section */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                     <div className="space-y-6">
                        <SectionTitle title="Executive Summary" />
                        <p className="text-slate-600 leading-relaxed text-sm">
                           The subject token <span className="font-bold text-slate-900">({result.features.symbol})</span> has been evaluated using a 3-layered Bayesian inference engine. 
                           The current probability of a liquidity exit or contract manipulation event is quantified at 
                           <span className={cn("px-2 py-0.5 rounded font-bold mx-1", result.probability > 0.7 ? "bg-red-500 text-white" : "bg-indigo-600 text-white")}>
                              {(result.probability * 100).toFixed(0)}%
                           </span>.
                        </p>
                        <div className="bg-slate-50 rounded-2xl p-6 border border-slate-200">
                           <h5 className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-4">Tactical Recommendation</h5>
                           <p className="text-xs font-medium text-slate-700">
                              {result.probability > 0.8 ? "ABORT: High-probability exit liquidity detected. Avoid deployment." : 
                               result.probability > 0.5 ? "CAUTION: Tactical gamble. Small allocations only with strict trailing stops." :
                               "MONITOR: Health markers optimal. Low rug risk but beware of standard market volatility."}
                           </p>
                        </div>
                     </div>
                     
                     <div className="space-y-6">
                        <SectionTitle title="Risk Breakdown" />
                        <div className="space-y-4">
                           <ReportMetric label="Contract Integrity" score={result.features.is_freeze_revoked ? 10 : 0} outOf={10} invert />
                           <ReportMetric label="Liquidity Security" score={Math.round(result.features.lp_burned_ratio * 10)} outOf={10} />
                           <ReportMetric label="Whale Accumulation" score={Math.min(result.features.smart_money_buyers_count, 5)} outOf={5} />
                           <ReportMetric label="Decentralization" score={Math.round((1 - result.features.top_10_ratio) * 10)} outOf={10} />
                        </div>
                     </div>
                  </div>

                  {/* Evidence Chain Section */}
                  <div className="space-y-8">
                     <SectionTitle title="Evidence Chain" />
                     <div className="bg-slate-900 rounded-3xl p-8 text-indigo-400 font-mono text-xs overflow-x-auto">
                        <table className="w-full text-left">
                           <thead>
                              <tr className="border-b border-indigo-500/20 text-indigo-200 uppercase tracking-widest text-[10px]">
                                 <th className="pb-4">Marker ID</th>
                                 <th className="pb-4 text-center">Inference Value</th>
                                 <th className="pb-4">Status</th>
                                 <th className="pb-4 text-right">Bayesian Weight</th>
                              </tr>
                           </thead>
                           <tbody className="divide-y divide-indigo-500/10">
                              {result.tags.map((tag, i) => (
                                 <tr key={i} className="group">
                                    <td className="py-5 font-bold uppercase">{tag}</td>
                                    <td className="py-5 text-center">
                                       <span className={cn(
                                          "px-2 py-1 rounded text-[9px]",
                                          tag.startsWith('rg_') ? "bg-red-500/10 text-red-500" : "bg-emerald-500/10 text-emerald-500"
                                       )}>
                                          {tag.startsWith('rg_') ? 'NEGATIVE' : 'POSITIVE'}
                                       </span>
                                    </td>
                                    <td className="py-5 text-slate-500">ACTIVE_SIGNAL</td>
                                    <td className="py-5 text-right font-bold text-slate-300">
                                       {tag === 'rg_honeypot_risk' ? '10.0x' : '1.5x - 5.0x'}
                                    </td>
                                 </tr>
                              ))}
                           </tbody>
                        </table>
                     </div>
                  </div>

                  {/* Advisory Disclaimer */}
                  <div className="pt-8 border-t border-slate-100 flex items-start gap-4">
                     <Info className="w-5 h-5 text-slate-400 mt-1 shrink-0" />
                     <p className="text-[10px] text-slate-400 font-medium leading-relaxed italic">
                        DISCLAIMER: This report is generated by GodView V2 Bayesian AI. Probabilities are estimates based on available on-chain data and do not constitute financial advice. Digital assets are highly volatile and risky. Intelligence is provided "as-is" for strategic informational purposes.
                     </p>
                  </div>
               </div>

               {/* Document Footer */}
               <div className="p-8 border-t border-slate-200 bg-slate-50 flex justify-between items-center">
                  <div className="flex gap-4">
                     <button className="flex items-center gap-2 text-xs font-bold text-slate-600 hover:text-indigo-600 transition-colors">
                        <Download className="w-4 h-4" /> Download PDF
                     </button>
                     <button className="flex items-center gap-2 text-xs font-bold text-slate-600 hover:text-indigo-600 transition-colors">
                        <Share2 className="w-4 h-4" /> Export Raw Data
                     </button>
                  </div>
                  <div className="text-[10px] font-mono text-slate-400 uppercase font-black">
                     Secure Hash: 0x{result.address.slice(0, 16)}...
                  </div>
               </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <footer className="max-w-7xl mx-auto px-6 py-12 border-t border-slate-200 flex flex-col md:flex-row justify-between items-center gap-6">
         <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">&copy; 2026 GodView Cyber-Intelligence Systems</p>
         <div className="flex gap-8 text-[10px] font-black uppercase text-slate-500 tracking-widest">
            <a href="#" className="hover:text-indigo-600 transition-colors">Terminal Terms</a>
            <a href="#" className="hover:text-indigo-600 transition-colors">API Uplink</a>
            <a href="#" className="hover:text-indigo-600 transition-colors">Risk Protocol</a>
         </div>
      </footer>
    </div>
  );
}

function StatBox({ label, value, danger = false }: { label: string; value: string; danger?: boolean }) {
  return (
    <div className="p-5 bg-slate-50 border border-slate-100 rounded-2xl space-y-1">
      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{label}</span>
      <div className={cn("text-lg font-bold truncate", danger ? "text-red-500" : "text-slate-900")}>{value}</div>
    </div>
  );
}

function FingerprintCard({ label, active, desc }: { label: string; active: boolean; desc: string }) {
  return (
    <div className={cn(
      "p-6 rounded-2xl border transition-all",
      active ? "bg-red-50 border-red-200" : "bg-emerald-50 border-emerald-200"
    )}>
      <div className="flex items-center gap-3 mb-3">
        {active ? <AlertTriangle className="w-4 h-4 text-red-600" /> : <ShieldCheck className="w-4 h-4 text-emerald-600" />}
        <span className={cn("text-[10px] font-black uppercase tracking-widest", active ? "text-red-600" : "text-emerald-600")}>
          {label}: {active ? "DETECTED" : "CLEAR"}
        </span>
      </div>
      <p className="text-[10px] font-medium text-slate-500 leading-relaxed uppercase">{desc}</p>
    </div>
  );
}

function SectionTitle({ title }: { title: string }) {
  return (
     <div className="flex items-center gap-4 mb-4">
        <h4 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] shrink-0">{title}</h4>
        <div className="h-[1px] w-full bg-slate-100" />
     </div>
  )
}

function ReportMetric({ label, score, outOf, invert = false }: { label: string; score: number; outOf: number; invert?: boolean }) {
   const isDanger = invert ? score < outOf : score < (outOf / 2);
   return (
      <div className="flex justify-between items-center group">
         <span className="text-xs font-bold text-slate-500 uppercase tracking-tight">{label}</span>
         <div className="flex gap-1">
            {[...Array(outOf)].map((_, i) => (
               <div 
                key={i} 
                className={cn(
                  "w-4 h-1.5 rounded-full transition-all duration-500",
                  i < score 
                  ? (isDanger ? "bg-red-500" : "bg-indigo-600") 
                  : "bg-slate-100"
                )} 
               />
            ))}
         </div>
      </div>
   )
}

function LoadingStub() {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="bg-white border border-slate-200 rounded-[2.5rem] p-24 flex flex-col items-center justify-center gap-12"
    >
      <div className="relative">
         <div className="w-32 h-32 border-4 border-indigo-100 rounded-full" />
         <div className="absolute inset-0 border-t-4 border-indigo-600 rounded-full animate-spin" />
         <Fingerprint className="absolute inset-0 m-auto w-12 h-12 text-indigo-600 animate-pulse" />
      </div>
      <div className="text-center space-y-3">
         <div className="text-xs font-black uppercase tracking-[0.4em] text-indigo-600 animate-pulse">Running Deep Trace Protocol</div>
         <p className="text-[10px] font-mono text-slate-400 uppercase italic">Mapping liquidity routes across Solana Mainnet...</p>
      </div>
    </motion.div>
  );
}

function ErrorStub({ message, retry }: { message: string, retry: () => void }) {
  return (
    <div className="bg-red-50 border border-red-200 p-16 rounded-[2.5rem] text-center">
      <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-8">
        <ShieldAlert className="w-10 h-10 text-red-600" />
      </div>
      <h3 className="text-3xl font-black text-red-700 mb-4 tracking-tight">Signal Interrupted</h3>
      <p className="text-red-600 font-medium mb-8 max-w-sm mx-auto opacity-70 italic text-sm">"{message}"</p>
      <button 
        onClick={retry}
        className="bg-red-600 hover:bg-red-700 text-white font-black py-4 px-12 rounded-2xl shadow-xl shadow-red-200"
      >
        RETRY UPLINK
      </button>
    </div>
  );
}
