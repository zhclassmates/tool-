export interface DeepForensics {
  isSameFunder: boolean;
  hasBlockSync: boolean;
  sharedJitoTipAccount: boolean;
  evidence?: {
    funderMap: Record<string, string[]>;
    syncClusters: Array<{ slot: number; count: number; addresses: string[] }>;
  };
}

export interface TokenFeatures {
  symbol: string;
  is_freeze_revoked: boolean;
  lp_burned_ratio: number;
  volume_24h: number;
  age_hours: number;
  smart_money_buyers_count: number;
  price_to_cost_ratio: number;
  top_10_ratio: number;
  dev_sold_all: boolean;
  forensics?: DeepForensics;
}

export class TagPipeline {
  /**
   * Evaluates features and returns a list of tags and the cumulative likelihood ratio (LR).
   * LR > 1 increases P(Rug), LR < 1 decreases it (bullish indicator).
   */
  public evaluate(features: TokenFeatures): { tags: string[]; likelihoodRatio: number } {
    const tags: string[] = [];
    let lr = 1.0;

    // --- High-Confidence Forensics (Physical Evidence) ---
    if (features.forensics) {
      if (features.forensics.isSameFunder && features.forensics.hasBlockSync) {
        tags.push('ws_insider_cant_hide');
        lr *= 45.0; // Terminal weight: Definite coordination
      } else if (features.forensics.isSameFunder) {
        tags.push('rg_shared_funding');
        lr *= 15.0; // Very high weight: Same parent wallet
      }
      
      if (features.forensics.sharedJitoTipAccount) {
        tags.push('rg_bundle_sniper');
        lr *= 12.0; // Very high risk: automated bundle manipulation
      }

      if (features.forensics.hasBlockSync && !tags.includes('ws_insider_cant_hide')) {
        tags.push('rg_block_sync_detected');
        lr *= 8.0; // High risk: cabal-style coordinated buying
      }
    }

    // --- Safety Layer (The Master Gate) ---
    if (!features.is_freeze_revoked) {
      tags.push('rg_honeypot_risk');
      lr *= 10.0; 
    }

    if (features.lp_burned_ratio < 0.6) {
      tags.push('rg_unlocked_liquidity');
      lr *= 6.0;
    } else {
      tags.push('ts_lp_secure');
      lr *= 0.3; // Significant reduction in risk
    }

    // --- Developer Behavior ---
    if (features.dev_sold_all) {
      tags.push('rg_dev_dumping');
      lr *= 3.5; 
      if (features.smart_money_buyers_count >= 3) {
        tags.push('cto_candidate');
        lr *= 0.15; // Strong CTO potential if smart money enters as dev exits
      }
    }

    // --- Market Behavior ---
    if (features.volume_24h > 1000000) {
      tags.push('ts_high_traction');
      lr *= 0.8; 
    }

    if (features.age_hours < 1) {
      tags.push('rg_extreme_early');
      lr *= 1.8;
    }

    if (features.smart_money_buyers_count >= 5) {
      tags.push('ts_smart_money_resonance');
      lr *= 0.1; // Extremely bullish forensic signal
    }

    if (features.top_10_ratio > 0.6 && !features.dev_sold_all) {
      tags.push('rg_whale_concentration');
      lr *= 3.0;
    }

    return { tags, likelihoodRatio: lr };
  }
}
