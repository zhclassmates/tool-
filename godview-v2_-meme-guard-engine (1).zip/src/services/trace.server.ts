import axios from 'axios';

const HELIUS_RPC = `https://mainnet.helius-rpc.com/?api-key=${process.env.HELIUS_API_KEY}`;

// Known CEX Hot Wallet fragments/addresses
const KNOWN_CEX_LIST = [
  'AC57B9ZpUebm4fSZ9Y8WGUSsaSp1y7G6z6qFv5y4g6zY', // Binance
  '5VCwfsy7hDsSSTVuj6Sgsh5oQyFStz6Rj7U4aXvB7PJP', // OKX
  'By32YvV_S_H_E_Z_A_H_A_D_A_S_T', // Bybit pattern
];

export interface FundingOrigin {
  funder: string;
  type: 'CEX' | 'CABAL' | 'UNKNOWN';
}

export class DeepTraceService {
  /**
   * Recursively trace the origin of a wallet's SOL to see if it comes from a CEX 
   * or a shared "cabal" funder.
   */
  async getOriginSource(address: string, depth = 3): Promise<FundingOrigin> {
    let currentAddress = address;
    
    try {
      for (let i = 0; i < depth; i++) {
        const genesisFunder = await this.getFirstIncomingSOL(currentAddress);
        if (!genesisFunder) break;

        // Check if funder is a known CEX
        if (KNOWN_CEX_LIST.some(cex => genesisFunder.includes(cex))) {
          return { funder: genesisFunder, type: 'CEX' };
        }
        
        currentAddress = genesisFunder;
      }

      return { funder: currentAddress, type: 'CABAL' };
    } catch (error) {
      console.error(`Trace failed for ${address}:`, error);
      return { funder: currentAddress, type: 'UNKNOWN' };
    }
  }

  private async getFirstIncomingSOL(address: string): Promise<string | null> {
    if (!process.env.HELIUS_API_KEY || !process.env.HELIUS_API_KEY.startsWith('http') && process.env.HELIUS_API_KEY.length < 10) {
       // Mock logic for preview if key is invalid/missing to show the UX
       return null;
    }

    try {
      // Get signatures for the address
      const response = await axios.post(HELIUS_RPC, {
        jsonrpc: "2.0",
        id: "trace",
        method: "getSignaturesForAddress",
        params: [address, { limit: 100 }]
      });

      const signatures = response.data?.result || [];
      if (signatures.length === 0) return null;

      // Find the oldest signature (the last one in the list if not more than 100)
      const oldestSig = signatures[signatures.length - 1].signature;

      // Parse the transaction
      const txResponse = await axios.post(HELIUS_RPC, {
        jsonrpc: "2.0",
        id: "parse",
        method: "getParsedTransaction",
        params: [oldestSig, { maxSupportedTransactionVersion: 0 }]
      });

      const tx = txResponse.data?.result;
      if (!tx || !tx.meta || !tx.transaction) return null;

      // Simplified logic: find the first signer or account that sent SOL
      // In a real implementation, we'd check instructions for 'transfer'
      const accountKeys = tx.transaction.message.accountKeys;
      const funder = accountKeys[0]?.pubkey || accountKeys[0]; // Usually the first signer

      return typeof funder === 'string' ? funder : funder.toString();
    } catch (e) {
      return null;
    }
  }

  async verifyFundingChain(addresses: string[]): Promise<{ isSameFunder: boolean, primaryFunder?: string, funderMap: Record<string, string[]> }> {
    if (addresses.length < 2) return { isSameFunder: false, funderMap: {} };
    
    const origins = await Promise.all(addresses.slice(0, 8).map(addr => this.getOriginSource(addr)));
    const funderMap: Record<string, string[]> = {};
    
    origins.forEach((origin, i) => {
      if (origin.type === 'CABAL') {
        const funder = origin.funder;
        if (!funderMap[funder]) funderMap[funder] = [];
        funderMap[funder].push(addresses[i]);
      }
    });

    let isSameFunder = false;
    let primaryFunder: string | undefined;

    for (const [funder, targets] of Object.entries(funderMap)) {
      if (targets.length >= 2) {
        isSameFunder = true;
        primaryFunder = funder;
        break;
      }
    }

    return { isSameFunder, primaryFunder, funderMap };
  }
}

export const traceService = new DeepTraceService();
