import axios from 'axios';
import { TokenFeatures } from '../engine/pipeline.ts';

export class BirdeyeService {
  private apiKey: string;
  private baseUrl = "https://public-api.birdeye.so";

  constructor(apiKey: string) {
    this.apiKey = apiKey;
  }

  private async makeRequest(endpoint: string) {
    try {
      const response = await axios.get(`${this.baseUrl}${endpoint}`, {
        headers: {
          "X-API-KEY": this.apiKey,
          "x-chain": "solana",
          "accept": "application/json"
        },
        timeout: 10000
      });
      return response.data?.data || {};
    } catch (error: any) {
      console.error(`❌ Birdeye API error (${endpoint}):`, error.message);
      return {};
    }
  }

  public async fetchTokenSecurity(address: string) {
    return this.makeRequest(`/defi/token_security?address=${address}`);
  }

  public async fetchTokenOverview(address: string) {
    return this.makeRequest(`/defi/token_overview?address=${address}`);
  }

  public async fetchTopTraders(address: string, limit: number = 10) {
    const data = await this.makeRequest(`/defi/v2/tokens/top_traders?address=${address}&offset=0&limit=${limit}`);
    return data?.items || [];
  }

  public async getGodviewFeatures(address: string): Promise<TokenFeatures | null> {
    console.log(`📡 Extracting features via Birdeye: ${address}...`);
    
    const securityData = await this.fetchTokenSecurity(address);
    let overviewData = await this.fetchTokenOverview(address);
    const tradersData = await this.fetchTopTraders(address);

    // Confidence and Robustness checks
    if ((!overviewData || Object.keys(overviewData).length === 0) && securityData && Object.keys(securityData).length > 0) {
      console.log("⚠️ Overview data missing for very new token, using security metadata fallback.");
      overviewData = {
        symbol: securityData.symbol || 'UNKNOWN',
        name: securityData.name || 'Unknown',
        v24hUSD: 0,
        creationTime: new Date().toISOString()
      };
    }

    if (!overviewData || Object.keys(overviewData).length === 0) {
      return null;
    }

    // Cleaning and Feature Engineering with higher robustness
    // Birdeye security fields can vary, so we check multiple potential names
    const is_freeze_revoked = securityData?.freezeAuthority === null || securityData?.freezeTx === null;
    
    // Check if minting is disabled (Renounced)
    const is_mint_disabled = securityData?.mintAuthority === null || securityData?.mintTx === null;
    
    // LP Burned Ratio: more sophisticated check
    let lp_burned_ratio = (securityData?.lpBurned === true || securityData?.isLpBurned === true) ? 1.0 : 0.0;
    // Fallback: If mint is disabled and it's a pump.fun token, it's often effectively safe early on
    if (lp_burned_ratio === 0 && is_mint_disabled && address.endsWith('pump')) {
      lp_burned_ratio = 0.8; // High confidence for pump tokens with disabled mint
    }

    let volume_24h = Number(overviewData.v24hUSD || overviewData.v24h || 0);
    
    // Top traders analysis
    const items = Array.isArray(tradersData) ? tradersData : [];
    const top10Volume = items.slice(0, 10).reduce((acc: number, t: any) => acc + (Number(t.volume) || 0), 0);
    
    // Fallback: If global volume is 0 but we see trader volume, use that.
    if (volume_24h === 0 && top10Volume > 0) {
      console.log(`📡 Using high-fidelity trader volume fallback: ${top10Volume}`);
      volume_24h = top10Volume * 1.5; // Estimating total volume based on top traders
    }

    const totalVolume = Math.max(volume_24h, 1);
    const top10Ratio = Math.min(top10Volume / totalVolume, 1.0);

    const smartMoneyCount = items.filter((t: any) => (Number(t.roi) || 0) > 10.0).length;

    const creationTime = overviewData.creationTime || securityData.creationTime;
    const ageHours = creationTime 
      ? (Date.now() - new Date(creationTime).getTime()) / (1000 * 60 * 60)
      : 24;

    const dev_sold_all = top10Ratio > 0.9 && volume_24h < 5000 && ageHours > 1;

    return {
      symbol: (overviewData.symbol || securityData.symbol || 'UNKNOWN').toUpperCase(),
      is_freeze_revoked,
      lp_burned_ratio,
      volume_24h,
      age_hours: Math.max(ageHours, 0.01), 
      smart_money_buyers_count: smartMoneyCount,
      price_to_cost_ratio: 1.0,
      top_10_ratio: top10Ratio,
      dev_sold_all
    };
  }
}
