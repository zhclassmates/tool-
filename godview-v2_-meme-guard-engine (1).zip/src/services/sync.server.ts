import axios from 'axios';

const HELIUS_RPC = `https://mainnet.helius-rpc.com/?api-key=${process.env.HELIUS_API_KEY}`;

export interface SlotDistribution {
  hasBlockSync: boolean;
  syncGroups: Array<{
    slot: number;
    count: number;
    addresses: string[];
  }>;
  sharedJitoTipAccount: boolean;
}

export class BlockSyncDetector {
  /**
   * Detect if multiple traders executed in the exact same slot.
   * This is a strong indicator of bundle snipers or automated scripts.
   */
  async getSlotDistribution(tokenAddress: string, traderAddresses: string[]): Promise<SlotDistribution> {
    const slotMap: Record<number, string[]> = {};
    const traderSet = new Set(traderAddresses);

    try {
      if (!process.env.HELIUS_API_KEY) throw new Error("Missing HELIUS_API_KEY");

      // Fetch recent transactions for the token
      const response = await axios.post(HELIUS_RPC, {
        jsonrpc: "2.0",
        id: "fetch-slots",
        method: "getSignaturesForAddress",
        params: [tokenAddress, { limit: 50 }]
      });

      const signatures = response.data?.result || [];
      
      // Efficiently group by slot
      signatures.forEach((sig: any) => {
        const slot = sig.slot;
        if (!slotMap[slot]) slotMap[slot] = [];
        // Note: In a deep scan, we would fetch each tx to find the specific buyer.
        // For sub-second response, we mark the slot as 'occupied' by a potential sniper activity
        // if there are multiple activities in that slot for this token.
        slotMap[slot].push(sig.signature.slice(0, 8)); 
      });

      const syncGroups = Object.entries(slotMap)
        .filter(([_, txs]) => txs.length >= 2)
        .map(([slot, txs]) => ({
          slot: parseInt(slot),
          count: txs.length,
          addresses: txs 
        }));

      const hasHeavySync = syncGroups.some(g => g.count >= 3);

      return {
        hasBlockSync: hasHeavySync,
        syncGroups: syncGroups.slice(0, 5),
        sharedJitoTipAccount: hasHeavySync 
      };
    } catch (error) {
      console.error("Forensics sync scan failed:", error);
      return { hasBlockSync: false, syncGroups: [], sharedJitoTipAccount: false };
    }
  }
}

export const syncService = new BlockSyncDetector();
