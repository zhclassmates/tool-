import { motion } from 'motion/react';
import { Network, Blocks, AlertTriangle, Fingerprint } from 'lucide-react';

interface ForensicsReportProps {
  evidence: {
    funderMap: Record<string, string[]>;
    syncClusters: Array<{ slot: number; count: number; addresses: string[] }>;
  };
}

export function ForensicsReport({ evidence }: ForensicsReportProps) {
  const hasClusters = evidence.syncClusters.some(c => c.count >= 2);
  const hasFunderOverlap = Object.keys(evidence.funderMap).length > 0;

  if (!hasClusters && !hasFunderOverlap) {
    return (
      <div className="p-8 bg-slate-900 rounded-3xl border border-slate-800 text-center">
        <p className="text-slate-500 text-xs font-mono">No significant physical fingerprints detected in this cycle.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Funding Homogeneity Lineage */}
      {hasFunderOverlap && (
        <section className="space-y-4">
          <div className="flex items-center gap-3">
            <Network className="w-5 h-5 text-indigo-400" />
            <h4 className="text-sm font-black text-indigo-100 uppercase tracking-widest">Cabal Funding Lineage</h4>
          </div>
          
          <div className="grid grid-cols-1 gap-4">
            {Object.entries(evidence.funderMap).map(([funder, addresses], idx) => (
              <motion.div 
                key={funder}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6 flex flex-col md:flex-row gap-6 items-center"
              >
                <div className="shrink-0 flex flex-col items-center gap-2">
                  <div className="w-12 h-12 rounded-full bg-indigo-500/10 flex items-center justify-center border border-indigo-500/20 shadow-[0_0_20px_rgba(79,70,229,0.1)]">
                    <Fingerprint className="w-6 h-6 text-indigo-400" />
                  </div>
                  <span className="text-[10px] font-mono text-indigo-400 font-bold">{funder.slice(0, 8)}...</span>
                </div>

                <div className="flex-1 flex flex-col gap-1 items-center md:items-start">
                   <div className="w-full h-[1px] bg-gradient-to-r from-indigo-500/50 to-transparent relative hidden md:block">
                      <div className="absolute -top-1 right-0 w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
                   </div>
                   <div className="flex flex-wrap gap-2 justify-center md:justify-start pt-4">
                      {addresses.map((addr) => (
                        <div key={addr} className="px-3 py-1 bg-red-500/10 border border-red-500/20 rounded text-[9px] font-mono text-red-400">
                          INSIDER_{addr.slice(0, 4)}
                        </div>
                      ))}
                   </div>
                   <p className="text-[10px] text-slate-500 mt-2 italic">Matched source funds detected across {addresses.length} strategic wallets.</p>
                </div>
              </motion.div>
            ))}
          </div>
        </section>
      )}

      {/* Block Slot Synchronization */}
      {hasClusters && (
        <section className="space-y-4">
          <div className="flex items-center gap-3">
            <Blocks className="w-5 h-5 text-amber-400" />
            <h4 className="text-sm font-black text-amber-100 uppercase tracking-widest">Block Sync Clusters</h4>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {evidence.syncClusters.map((cluster, idx) => (
              <motion.div 
                key={cluster.slot}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex justify-between items-center"
              >
                <div>
                  <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Slot Identification</div>
                  <div className="text-amber-400 font-mono text-sm">#{cluster.slot}</div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-black text-white">{cluster.count}x</div>
                  <div className="text-[9px] font-bold text-slate-500 uppercase">Synchronized TXs</div>
                </div>
                {cluster.count >= 3 && (
                  <div className="absolute -top-2 -right-2 bg-red-600 text-white p-1 rounded-full animate-bounce">
                    <AlertTriangle className="w-3 h-3" />
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
